import mongoose from "mongoose";

const bannerSchema = new mongoose.Schema(
  {
    image: {
      type: String,
      required: true,
    },
    promotionLocation: [
      {
        type: String,
        enum: ["Home Screen", "Score Summary", "Search Screen"],
        required: true,
      },
    ],
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
      required: true,
    },
    locationHistory: {
      point: {
        type: {
          type: String,
          enum: ["Point"],
          default: "Point",
          required: true,
        },
        coordinates: {
          type: [Number],
          required: true,
          validate: {
            validator: function (arr) {
              return arr.length === 2; // Ensure coordinates array has exactly 2 values
            },
            message:
              "Coordinates should contain exactly 2 numbers (longitude and latitude).",
          },
        },
      },
    },
    promotionFor: {
      type: String,
      enum: ["Tournament", "Shop"],
      required: true,
    },
    // payments: [
    //   {
    //     paymentid: {
    //       type: mongoose.Schema.Types.ObjectId,
    //       ref: "Payment",
    //     },
    //     amount: Number,
    //   },
    // ],
    userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    createdAt: {
      type: Date,
      default: Date.now,
    },
  },
  { collection: "bannerPromotion" }
);

export default mongoose.model("BannerPromo", bannerSchema);
