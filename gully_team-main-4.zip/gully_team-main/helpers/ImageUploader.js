import { PutObjectCommand, DeleteObjectCommand,S3Client } from "@aws-sdk/client-s3";
import {
  AWS_ACCESS_KEY_ID,
  AWS_BUCKET_NAME,
  AWS_SECRET_ACCESS_KEY,
} from "../config/index.js";

class ImageUploader {

    static s3Client = new S3Client({
      region: "ap-south-1",
      credentials: {
        accessKeyId: AWS_ACCESS_KEY_ID,
        secretAccessKey: AWS_SECRET_ACCESS_KEY,
      },
    });
      // to Upload image to S3 bucket
    static async Upload(base64Image, folderName, fileName = "default") {
      if (!this.s3Client) {
      throw new Error("S3 client is not initialized correctly.");
    }
    // Check if the base64Image starts with a valid image prefix
    let contentType;
    if (base64Image.startsWith("data:image/png;base64,")) {
      contentType = "image/png";
    } else if (base64Image.startsWith("data:image/jpeg;base64,")) {
      contentType = "image/jpeg";
    } else {
      throw new Error("Unsupported image format");
    }

    // Decode the base64 string to a buffer
    const buffer = Buffer.from(
      base64Image.replace(/^data:image\/\w+;base64,/, ""),
      "base64"
    );
    let key = "";
    if (fileName === "default") {
      key = `${folderName}/${Date.now().toString()}.${
        contentType.split("/")[1]
      }`;
    } else {
      key = fileName;
    }

    const uploadParams = {
      Bucket: AWS_BUCKET_NAME,
      Key: key,
      Body: buffer,
      ContentType: contentType,
    };

    // Upload the photo to the S3 bucket
    try {
      const command = new PutObjectCommand(uploadParams);
      await this.s3Client.send(command);
      return key;
    } catch (error) {
      throw new Error(`Failed to upload image to S3: ${error.message}`);
    }
  }

  // Method to delete image from S3 bucket
  static async Delete(s3Key) {
    const deleteParams = {
      Bucket: AWS_BUCKET_NAME,
      Key: s3Key,
    };

    try {
      const command = new DeleteObjectCommand(deleteParams);
      await this.s3Client.send(command);
    } catch (error) {
      throw new Error(`Failed to delete image from S3: ${error.message}`);
    }
  }
}

export default ImageUploader;
