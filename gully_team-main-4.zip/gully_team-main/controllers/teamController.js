import Joi from "joi";
import CustomErrorHandler from "../helpers/CustomErrorHandler.js";
import { Team } from "../models/index.js";
import { adminService, teamServices } from "../services/index.js";
import firebaseNotification from "../helpers/firebaseNotification.js";

const teamController = {
  async getTeamById(req, res, next) {
    let TeamId = req.params.Id;
    try {
      const result = await teamServices.getTeamById(TeamId);

      return res.status(200).json({
        sucess: true,
        message: "Team Retrieved Successfully",
        data: result,
      });
    } catch (err) {
      console.log(" Error in  getTeamById");
      return next(err);
    }
  },

  async teamListByTournamentID(req, res, next) {
    let TeamId = req.params.Id;
    try {
      const result = await teamServices.getTeamById(TeamId);

      return res.status(200).json({
        success: true,
        message: "Team Retrieved Successfully",
        data: result,
      });
    } catch (err) {
      console.log(" Error in  getTeamById");
      return next(err);
    }
  },

  async getAllTeams(req, res, next) {
    try {
      const result = await teamServices.getAllTeams();

      return res.status(200).json({
        success: true,
        message: "All Team Retrieved Successfully",
        data: { teams: result },
      });
    } catch (err) {
      console.log(" Error in getAllTeams");
      return next(err);
    }
  },

  async getUserTeams(req, res, next) {
    try {
      const result = await teamServices.getUserTeams();

      return res.status(200).json({
        success: true,
        message: "All Team Retrieved Successfully",
        data: { teams: result },
      });
    } catch (err) {
      console.log(" Error in getUserTeams");
      return next(err);
    }
  },

  async createTeam(req, res, next) {
    //validation
    const teamValidation = Joi.object({
      //teamName:Joi.string().regex(/^[a-zA-Z\s][a-zA-Z0-9-\s]*$/).min(3).max(30).required(),
      teamName:Joi.string().regex(/^[a-zA-Z][a-zA-Z0-9\s-]*$/).min(3).max(30).required()
      .messages({
        'string.base': 'Name must be a string',
        'string.pattern.base': 'Name must start with a letter and can contain letters, numbers, spaces, and dashes only',
        'string.empty': 'Name is required',
        'any.required': 'Name is required',
        'string.min': 'Name must have at least {#limit} characters',
        'string.max': 'Name must have at most {#limit} characters'
    }),
      teamLogo: Joi.string().optional(),
      // tournamentId: Joi.string().required(), //DG
    });

    const { error } = teamValidation.validate(req.body);

    if (error) {
      return next(error);
    }

    //verify teamName aready exist
    // const TeamNameExist = await Team.exists({ teamName: req.body.teamName });

    // if (TeamNameExist) {
    //   return next(
    //     CustomErrorHandler.alreadyExist("This Team Name already present.")
    //   );
    // }

    try {
      
      const { teamdata, fcmToken } = await teamServices.createTeam(req.body,);

    // for notification
      //await adminService.sendNotification(fcmToken,`Team Created!🏅  Congratulations! Your team ${teamdata.teamName} has been successfully created.`);

      const notificationData = {
        title: "Gully Team",
        body: `Team Created!🏅  Congratulations! Your team ${teamdata.teamName} has been successfully created.`,
        image: "",
      };

      if (fcmToken) {
         await firebaseNotification.sendNotification(
          fcmToken,
          notificationData
        );
      }
  
      return res.status(200).json({
        success: true,
        message: "profile created successfully",
        data: teamdata,
      });
    } catch (err) {
      console.log("Error in createTeam");
      return next(err);
    }
  },

  async editTeam(req, res, next) {
    let TeamId = req.params.Id;
    // Validation
    const teamValidation = Joi.object({
      teamLogo: Joi.string().optional(),
      teamName: Joi.string().required(),
    });
  
    const { error } = teamValidation.validate(req.body);
  
    if (error) {
      return next(error);
    }
  
    const team = await Team.findById(TeamId);
  
    if (!team) {
      return next(CustomErrorHandler.notFound("Team not found"));
    }
  
    if (team.teamName !== req.body.teamName) {
      // Check if team name already exists
      const TeamNameExist = await Team.exists({
        teamName: req.body.teamName,
      });
  
      if (TeamNameExist) {
        return next(
          CustomErrorHandler.alreadyExist(
            "This Team Name is already taken. Please try another name."
          )
        );
      }
    }
  
    try {
      const result = await teamServices.editTeam(req.body, TeamId);
  
      return res.status(200).json({
        success: true,
        message: "Profile edited successfully",
        data: result,
      });
    } catch (err) {
      console.log("Error in editTeam");
      return next(err);
    }
  },

  // async addPlayer(req, res, next) {
  //   let TeamId = req.params.Id;
  //   // Validation
  //   const playerValidation = Joi.object({
  //     name: Joi.string().regex(/^[a-zA-Z\s][a-zA-Z0-9-\s]*$/).min(1).max(255).required(),
  //     phoneNumber: Joi.string().pattern(/^\d{10}$/).required(),
  //     role: Joi.string().valid("Batsman", "Bowler", "All Rounder", "Wicket Keeper").required(),

  //   });
  
  //   const { error } = playerValidation.validate(req.body);
  
  //   if (error) {
  //     return next(error);
  //   }
  
  //   try {
  //     // Add the player to the team
  //     const { teamdata, fcmToken } = await teamServices.addPlayer(req.body, TeamId);
  
  //     const notificationData = {
  //       title: "Gully Team",
  //       body: `Exciting news! You've been added to team ${teamdata.teamName} by the captain.`,
  //       image: "",
  //     };
  
  //     if (fcmToken) {
  //       await firebaseNotification.sendNotification(fcmToken, notificationData);
  //     }
  
  //     return res.status(200).json({
  //       success: true,
  //       message: "Player added successfully",
  //       data: teamdata,
  //     });
  //   } catch (err) {
  //     console.log("Error in addPlayer");
  //     return next(err);
  //   }
  // },
  async addPlayer(req, res, next) {
    let TeamId = req.params.Id;
    // Validation
    const playerValidation = Joi.object({
      name: Joi.string().regex(/^[a-zA-Z\s][a-zA-Z0-9-\s]*$/).min(1).max(255).required(),
      phoneNumber: Joi.string().pattern(/^\d{10}$/).required(),
      role: Joi.string().valid("Batsman", "Bowler", "All Rounder", "Wicket Keeper").required(),
    });
  
    const { error } = playerValidation.validate(req.body);
  
    if (error) {
      return next(error);
    }
  
    try {
      // Add the player to the team
      const { teamdata, fcmToken } = await teamServices.addPlayer(req.body, TeamId, req.user);
  
      const notificationData = {
        title: "Gully Team",
        body: `Exciting news! You've been added to team ${teamdata.teamName} by the captain.`,
        image: "",
      };
  
      if (fcmToken) {
        await firebaseNotification.sendNotification(fcmToken, notificationData);
      }
  
      return res.status(200).json({
        success: true,
        message: "Player added successfully",
        data: teamdata,
      });
    } catch (err) {
      console.log("Error in addPlayer");
      return next(err);
    }
  },
  
  
  async deletePlayer(req, res, next) {
    let teamId = req.params.teamId;
    let playerId = req.params.playerId;
  
    try {
      const result = await teamServices.deletePlayer(teamId, playerId);
  
      return res.status(200).json({
        success: true,
        message: "Player deleted successfully",
        data: result,
      });
    } catch (err) {
      console.log("Error in deletePlayer");
      return next(err);
    }
  },
  async changeCaptain(req, res, next) {
    try {
        const { teamId } = req.params;
        const { newCaptainId, newRole, previousCaptainId, previousCaptainRole } = req.body;

        // Validate the data
        if (!newCaptainId || !newRole || !previousCaptainId) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields (newCaptainId, newRole, or previousCaptainId)',
            });
        }

        const result = await teamServices.changeCaptain(
            req.user.id, 
            teamId, 
            newCaptainId, 
            newRole, 
            previousCaptainId, 
            previousCaptainRole
        );

        res.status(200).json({
            success: true,
            message: 'Captain changed successfully',
            data: result,
        });
    } catch (err) {
        console.log('Error in changeCaptain:', err.message);
        next(err); // Pass error to the next middleware or error handler
    }
},



  // async editTeam(req, res, next) {
  //   let TeamId = req.params.Id;
  //   //validation
  //   const teamValidation = Joi.object({
  //     teamLogo: Joi.string().optional(),
  //     teamName: Joi.string().required(),
  //   });

  //   const { error } = teamValidation.validate(req.body);

  //   if (error) {
  //     return next(error);
  //   }

  //   const team = await Team.findById(TeamId);

  //   if (team.teamName !== req.body.teamName) {
  //     //verify phone Number aready exist
  //     const TeamNameExist = await Team.exists({
  //       teamName: req.body.teamName,
  //     });

  //     if (TeamNameExist) {
  //       return next(
  //         CustomErrorHandler.alreadyExist(
  //           "This Tournament Name already Taken. Please try another Name"
  //         )
  //       );
  //     }
  //   }
  //   try {
  //     const result = await teamServices.editTeam(req.body, TeamId);

  //     return res.status(200).json({
  //       success: true,
  //       message: "profile edited successfully",
  //       data: result,
  //     });
  //   } catch (err) {
  //     console.log("Error in editTeam");
  //     return next(err);
  //   }
  // },

  // async addPlayer(req, res, next) {
  //   let TeamId = req.params.Id;
  //   //validation
  //   const playerValidation = Joi.object({
  //     //it is old validation
  //     //name: Joi.string().regex(/^[a-zA-Z][a-zA-Z0-9-]*$/).min(1).max(255).required(),
  //     //new validation(22-05)
  //    name: Joi.string().regex(/^[a-zA-Z\s][a-zA-Z0-9-\s]*$/).min(1).max(255).required(),


  //     phoneNumber: Joi.string()
  //       .pattern(/^\d{10}$/)
  //       .required(),
  //     role: Joi.string()
  //       .valid("Batsman", "Bowler", "All Rounder", "Wicket Keeper")
  //       .required(),
  //   });

  //   const { error } = playerValidation.validate(req.body);

  //   if (error) {
  //     return next(error);
  //   }

  //   try {
  //     const { teamdata, fcmToken } = await teamServices.addPlayer(
  //       req.body,
  //       TeamId
  //     );

  //     //await adminService.sendNotification(registrationToken,`Exciting news! You've been added to  ${teamdata.teamName} by the captain`);

  //     const notificationData = {
  //       title: "Gully Team",
  //       body: `Exciting news! You've been added to team  ${teamdata.teamName} by the captain`,
  //       image: "",
  //     };

  //     if (fcmToken) {
  //       await firebaseNotification.sendNotification(
  //         fcmToken,
  //         notificationData
  //       );
       
  //     }

  //     return res.status(200).json({
  //       success: true,
  //       message: "Player Added successfully",
  //       data: teamdata,
  //     });
  //   } catch (err) {
  //     console.log("Error in createTeam");
  //     return next(err);
  //   }
  // },

  // async deletePlayer(req, res, next) {
  //   let teamId = req.params.teamId;
  //   let playerId = req.params.playerId;

  //   try {
  //     const result = await teamServices.deletePlayer(teamId, playerId);

  //     return res.status(200).json({
  //       success: true,
  //       message: "Player deleted successfully",
  //       data: result,
  //     });
  //   } catch (err) {
  //     console.log("Error in editTeam");
  //     return next(err);
  //   }
  // },

  async addLookingFor(req, res, next) {
    //validation
    const playerValidation = Joi.object({
      latitude: Joi.number().required(),
      longitude: Joi.number().required(),
      placeName: Joi.string().required(),
      role: Joi.string().required(),
      // role: Joi.string()
      //   .valid("Batsman", "Bowler", "All Rounder", "Wicket Keeper")
      //   .required(),
    });

    const { error } = playerValidation.validate(req.body);

    if (error) {
      return next(error);
    }

    try {
      const result = await teamServices.addLookingFor(req.body);

      return res.status(200).json({
        success: true,
        message: "Add Looking For Added successfully",
        data: result,
      });
    } catch (err) {
      console.log("Error in addLookingFor",err);
      return next(err);
    }
  },

  async deleteLookingFor(req, res, next) {
    const lookingId = req.params.lookingId;

    try {
      const result = await teamServices.deleteLookingFor(lookingId);

      return res.status(200).json({
        success: true,
        message: " Looking deleted successfully",
        data: result,
      });
    } catch (err) {
      console.log("Error in deleteLookingFor");
      return next(err);
    }
  },

  async getAllLooking(req, res, next) {
    try {
      const result = await teamServices.getAllLooking(req.body);

      return res.status(200).json({
        success: true,
        message: "All Looking Retrieved Successfully",
        data: result,
      });
    } catch (err) {
      console.log(" Error in  getAllLooking");
      return next(err);
    }
  },

  async getAllNearByTeam(req, res, next) {
    try {
      const result = await teamServices.getAllNearByTeam(req.body);

      return res.status(200).json({
        success: true,
        message: "getAllNearByTeam Retrieved Successfully",
        data: { teams: result },
      });
    } catch (err) {
      console.log(" Error in  getAllNearByTeam");
      return next(err);
    }
  },

  async getLookingByID(req, res, next) {
    const lookingId = req.params.lookingId;

    try {
      const result = await teamServices.getLookingByID();

      return res.status(200).json({
        success: true,
        message: "Users Looking Retrieved Successfully",
        data: { data: result },
      });
    } catch (err) {
      console.log(" Error in  getLookingByID");
      return next(err);
    }
  },

  

  // async editPlayer(req, res, next) {
  //   const teamId = req.params.teamId;
  //   const playerId = req.params.playerId;

  //   //validation
  //   const playerValidation = Joi.object({
  //     name: Joi.string().min(1).max(255).required(),
  //     phoneNumber: Joi.string().pattern(/^\d{10}$/).required(),
  //     role: Joi.string().valid('Batsman', 'Bowler', 'All Rounder','Wicket Keeper').required(),
  //   });

  //   const { error } = playerValidation.validate(req.body);

  //   if (error) {
  //     return next(error);
  //   }

  //   try {

  //     const result = await teamServices.editPlayer(req.body,TeamId,playerId);

  //     return res.status(200).json({
  //       sucess: true,
  //       message: "TeamPlayer Edited suessfully",
  //       data: result,
  //     });
  //   } catch (err) {
  //     console.log("Error in editPlayer");
  //     return next(err);
  //   }
  // },

  //DG
  async updateMatchResult(req, res){
    try {
      const matchResult = req.body; // Expecting matchResult object in the request body
      if (!matchResult || !matchResult.winningTeamId) {
        return res.status(400).json({ message: "Invalid match result data" });
      }
  
      // Call the service layer to update points table
      await teamServices.updatePointsTable(matchResult);
  
      // Send success response
      res.status(200).json({ message: "Points table updated successfully" });
    } catch (err) {
      console.error("Error in updateMatchResult:", err);
      res
        .status(500)
        .json({ message: "Error updating points table", error: err.message });
    }
  },
  


//3
// async fetchPointsTable(req, res) {
//   try {
//       const { tournamentId } = req.params; // Get tournamentId from request parameters
//       const pointsTable = await teamServices.getPointsTable(tournamentId);

//       res.status(200).json({
//           success: true,
//           message: "Points Table Retrieved Successfully",
//           data: {
//               TeamPoints: pointsTable,
//           },
//       });
//   } catch (err) {
//       console.error(err);
//       res.status(500).json({
//           success: false,
//           message: "Error fetching points table",
//           error: err.message,
//       });
//   }
// },

//4
async fetchPointsTable(req, res) {
  try {
      const { tournamentId } = req.params; // Get tournamentId from request parameters
      const pointsTable = await teamServices.getPointsTable(tournamentId); // Call service method

      if (!pointsTable || pointsTable.length === 0) {
          return res.status(404).json({
              success: false,
              message: "No points table data found for the given tournament.",
          });
      }

      res.status(200).json({
          success: true,
          message: "Points Table Retrieved Successfully",
          data: {
              TeamPoints: pointsTable,
          },
      });
  } catch (err) {
      console.error("Error fetching points table:", err.message);
      res.status(500).json({
          success: false,
          message: "Error fetching points table",
          error: err.message,
      });
  }
},



  };


export default teamController;

