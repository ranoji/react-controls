import Banner from '../models/bannerPromol.js';
import Tournament from '../models/tournament.js';
import Shop from '../models/shopModel.js';
import ImageUploader from '../helpers/ImageUploader.js';
import { bannerService } from "../services/index.js";
import Joi from "joi";

const bannerController = {
    async createBanner(req, res) {
        const bannerSchema = Joi.object({
            image: Joi.string().uri().required().pattern(/^data:image\/[a-zA-Z]+;base64,/),
            promotionLocation: Joi.array().items(Joi.string().valid("Home Screen", "Score Summary", "Search Screen")).required(),
            startDate: Joi.date().iso().required(),
            endDate: Joi.date().iso().min(Joi.ref("startDate")).required(),
            locationHistory: Joi.object({
                point: Joi.object({
                    type: Joi.string().valid("Point").default("Point"),
                    coordinates: Joi.array().items(Joi.number()).length(2).required()
                }).required()
            }).required(),
            promotionFor: Joi.string().valid("Tournament", "Shop").required(),
            payments: Joi.array().items(Joi.object({
                amount: Joi.number().positive().optional(),
                currency: Joi.string().max(3).optional(),
            })).optional()
        });

        const { error, value } = bannerSchema.validate(req.body, { allowUnknown: false });
        if (error) {
            return res.status(400).json({
                error: "Validation failed",
                details: error.details.map(detail => detail.message)
            });
        }

        try {
            const bannerData = {
                ...value,
                userId: req.user.userId
            };
            const result = await bannerService.createBanner(bannerData);
            res.status(201).json(result);
        } catch (err) {
            res.status(500).json({ error: 'Server Error', details: err.message });
        }
    },

    // async getBanner(req, res) {
    //     try {
    //         const { id } = req.params;
    //         const banner = await Banner.findById(id);
    //         if (!banner) {
    //             return res.status(404).json({ message: 'Banner not found' });
    //         }
    //         res.status(200).json({ banner });
    //     } catch (err) {
    //         res.status(500).json({ error: 'Error fetching banner', details: err.message });
    //     }
    // },
    
//DG commented code on 6/12/24
    // async getBanner(req, res) {
    //     try {
    //         const { id } = req.params;
    //         const banner = await Banner.findById(id);
    
    //         if (!banner) {
    //             return res.status(404).json({ message: 'Banner not found' });
    //         }
    
    //         res.status(200).json({
    //             success: true,
    //             message: "Banner retrieved Successfully",
    //             banner: {
    //                 image: banner.image,
    //                 promotionLocation: banner.promotionLocation,
    //                 startDate: banner.startDate,
    //                 endDate: banner.endDate,
    //                 locationHistory: {
    //                     point: {
    //                         type: "Point",
    //                         coordinates: banner.locationHistory.point.coordinates,
    //                     },
    //                 },
    //                 promotionFor: banner.promotionFor,
    //                 userId: banner.userId,
    //                 _id: banner._id,
    //                 createdAt: banner.createdAt,
    //                 __v: banner.__v,
    //             }
    //         });
    //     } catch (err) {
    //         res.status(500).json({ error: 'Error fetching banner', details: err.message });
    //     }
    // },
    

    async updateBanner(req, res) {
        const bannerSchema = Joi.object({
            image: Joi.string().uri().pattern(/^data:image\/[a-zA-Z]+;base64,/),
            promotionLocation: Joi.array().items(Joi.string().valid("Home Screen", "Score Summary", "Search Screen")).required(),
            startDate: Joi.date().iso().required(),
            endDate: Joi.date().iso().min(Joi.ref("startDate")).required(),
            locationHistory: Joi.object({
                point: Joi.object({
                    type: Joi.string().valid("Point").default("Point"),
                    coordinates: Joi.array().items(Joi.number()).length(2).required()
                }).required()
            }).required(),
            promotionFor: Joi.string().valid("Tournament", "Shop").required(),
        });

        const { error } = bannerSchema.validate(req.body);
        if (error) {
            return res.status(400).json({
                error: "Validation failed",
                details: error.details.map(detail => detail.message)
            });
        }

        try {
            const { id } = req.params;
            const updateData = { ...req.body };

            if (updateData.image) {
                const folderName = 'bannerPromotion';
                const fileName = `${Date.now()}_bannerImage`;
                const s3Key = await ImageUploader.Upload(updateData.image, folderName, fileName);
                updateData.image = s3Key;
            }

            const updatedBanner = await Banner.findByIdAndUpdate(id, updateData, { new: true, runValidators: true });
            if (!updatedBanner) {
                return res.status(404).json({ message: 'Banner not found for update' });
            }

            res.status(200).json({ message: 'Banner updated successfully', banner: updatedBanner });
        } catch (err) {
            res.status(500).json({ error: 'Error updating banner', details: err.message });
        }
    },

    async deleteBanner(req, res) {
        try {
            const { id } = req.params;
            const deletedBanner = await Banner.findById(id);
            if (!deletedBanner) {
                return res.status(404).json({ message: 'Banner not found for deletion' });
            }

            if (deletedBanner.image) {
                await ImageUploader.Delete(deletedBanner.image);
            }
            await deletedBanner.deleteOne();
            res.status(200).json({ message: 'Banner deleted successfully' });
        } catch (err) {
            res.status(500).json({ error: 'Error deleting banner', details: err.message });
        }
    },

    // Fetch tournaments for the logged-in user
    async getTournaments(req, res) {
        try {
            const userId = req.user._id;
            const tournaments = await Tournament.find({
                creator: userId,
                status: { $ne: 'deleted' }  // Added status check
            }).select('name startDate endDate location');  // Added field selection

            if (!tournaments.length) {
                return res.status(404).json({ message: "No tournaments found for the user." });
            }

            res.status(200).json({ tournaments });
        } catch (err) {
            res.status(500).json({ error: 'Error fetching tournaments', details: err.message });
        }
    },

    // Fetch shops for the logged-in user
    async getShops(req, res) {
        try {
            const userId = req.user._id;
            const shops = await Shop.find({
                owner: userId,
                status: { $ne: 'deleted' }  // Added status check
            }).select('name location');  // Added field selection

            if (!shops.length) {
                return res.status(404).json({ message: "No shops found for the user." });
            }

            res.status(200).json({ shops });
        } catch (err) {
            res.status(500).json({ error: 'Error fetching shops', details: err.message });
        }
    }
};

export default bannerController;