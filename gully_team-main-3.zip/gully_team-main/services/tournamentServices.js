import { Types } from "mongoose";
import CustomErrorHandler from "../helpers/CustomErrorHandler.js";
import {
  EntryForm,
  Match,
  RegisteredTeam,
  Team,
  Tournament,
  User,
} from "../models/index.js";

import ImageUploader from "../helpers/ImageUploader.js";
import firebaseNotification from "../helpers/firebaseNotification.js";

import moment from "moment";
const tournamentServices = {
  async createTournament(data, userStartDate, userEndDate) {
    const userInfo = global.user;

    let coHostId1;
    let coHostId2;

    if (data.coHost1Phone) {
      const existingUser = await User.findOne({ phoneNumber: data.coHost1Phone });

      if (existingUser) {
        coHostId1 = existingUser._id;
      } else {
        const newUser = new User({
          fullName: data.coHost1Name || "",
          phoneNumber: data.coHost1Phone,
          registrationDate: new Date(),
        });

        const newUserData = await newUser.save();
        coHostId1 = newUserData._id;
      }
    }

    if (data.coHost2Phone) {
      const existingUser = await User.findOne({ phoneNumber: data.coHost2Phone });

      if (existingUser) {
        coHostId2 = existingUser._id;
      } else {
        const newUser = new User({
          fullName: data.coHost2Name || "",
          phoneNumber: data.coHost2Phone,
          registrationDate: new Date(),
        });

        const newUserData = await newUser.save();
        coHostId2 = newUserData._id;
      }
    }

    let imagePath = "";
    if (data.coverPhoto) {
      imagePath = await ImageUploader.Upload(data.coverPhoto, "tournament");
    }

    const tournament = new Tournament({
      tournamentStartDateTime: userStartDate,
      tournamentEndDateTime: userEndDate,
      tournamentName: data.tournamentName,
      tournamentCategory: { name: data.tournamentCategory },
      ballType: { name: data.ballType },
      pitchType: { name: data.pitchType },
      email: userInfo.email,
      matchType: { name: data.matchType },
      tournamentPrize: { name: data.tournamentPrize },
      rules: data.rules,
      disclaimer: data.disclaimer,
      fees: data.fees,
      ballCharges: data.ballCharges,
      breakfastCharges: data.breakfastCharges,
      stadiumAddress: data.stadiumAddress,
      tournamentLimit: data.tournamentLimit,
      gameType: { name: data.gameType },
      coverPhoto: imagePath,
      locationHistory: {
        point: {
          coordinates: [parseFloat(data.longitude), parseFloat(data.latitude)],
        },
        selectLocation: data.selectLocation,
      },
      user: userInfo.userId,
      coHostId1: coHostId1,
      coHostId2: coHostId2,
      authority: userInfo.userId,
      isActive: true, // Set active status to true during creation
    });

    const newTournament = await tournament.save();
    await newTournament.populate("user");

    const user = await User.findById(userInfo.userId);
    user.isOrganizer = true;
    const fcmToken = user.fcmToken;

    await user.save();

    return { newTournament, fcmToken };
  },

// const tournamentServices = {
//   async createTournament(data, userStartDate, userEndDate) {
//     const userInfo = global.user;

//     //code for coHost.

//     let coHostId1;
//     let coHostId2;

//     if (data.coHost1Phone) {
//       const existingUser = await User.exists({
//         phoneNumber: data.coHost1Phone,
//       });

//       if (existingUser) {
//         coHostId1 = existingUser._id;
//       } else {
//         const newUser = new User({
//           fullName: data.coHost1Name || "",
//           phoneNumber: data.coHost1Phone,
//           registrationDate: new Date(),
//         });

//         const newUserData = await newUser.save();
//         coHostId1 = newUserData._id;
//       }
//     }

//     if (data.coHost2Phone) {
//       const existingUser = await User.exists({
//         phoneNumber: data.coHost2Phone,
//       });

//       if (existingUser) {
//         coHostId2 = existingUser._id;
//       } else {
//         const newUser = new User({
//           fullName: data.coHost2Name || "",
//           phoneNumber: data.coHost2Phone,
//           registrationDate: new Date(),
//         });

//         const newUserData = await newUser.save();
//         coHostId2 = newUserData._id;
//       }
//     }

//     let imagePath = "";
//     if (data.coverPhoto) {
//       imagePath = await ImageUploader.Upload(data.coverPhoto, "tournament");
//     }

//     // tournament object
//     const tournament = new Tournament({
//       tournamentStartDateTime: userStartDate,
//       tournamentEndDateTime: userEndDate,
//       tournamentName: data.tournamentName,
//       tournamentCategory: { name: data.tournamentCategory },
//       ballType: { name: data.ballType },
//       pitchType: { name: data.pitchType },
//       email: userInfo.email,
//       matchType: { name: data.matchType },
//       tournamentPrize: { name: data.tournamentPrize },
//       rules: data.rules,
//       disclaimer: data.disclaimer,
//       fees: data.fees,
//       ballCharges: data.ballCharges,
//       breakfastCharges: data.breakfastCharges,
//       stadiumAddress: data.stadiumAddress,
//       tournamentLimit: data.tournamentLimit,
//       gameType: { name: data.gameType },
//       coverPhoto: imagePath,
//       locationHistory: {
//         // type: "Point",

//         point: {
//           coordinates: [parseFloat(data.longitude), parseFloat(data.latitude)],
//         },
//         selectLocation: data.selectLocation,
//       },
//       user: userInfo.userId,
//       coHostId1: coHostId1,
//       coHostId2: coHostId2,
//       authority: userInfo.userId,
//     });

//     // Create a new instance of the HelpdeskTicket model
//     const newTournament = new Tournament(tournament);

//     // Save the new HelpdeskTicket and wait for the operation to complete
//     await newTournament.save();
//     newTournament.populate("user");

//     const user = await User.findById(userInfo.userId);
//     // Update the User as Organizer ;
//     user.isOrganizer = true;

//     // Retrieve FCM token this is for notification
//     const fcmToken = user.fcmToken;

//     // Save the updated user document
//     await user.save();
//     //this is for notification
//     return { newTournament, fcmToken };
//   },
async editTournament(data, userStartDate, userEndDate, tournamentId) {
  const userInfo = global.user;

  // Find the existing tournament by ID
  const tournament = await Tournament.findById(tournamentId);
  if (!tournament) {
    throw CustomErrorHandler.notFound("Tournament not found.");
  }

  let imagePath;
  if (data.coverPhoto) {
    // Handle image upload
    imagePath = await ImageUploader.Upload(data.coverPhoto, "tournament", tournament.coverPhoto);
  } else {
    imagePath = tournament.coverPhoto; // Retain the existing cover photo if none provided
  }

  let coHostId1 = tournament.coHostId1;
  let coHostId2 = tournament.coHostId2;

  // Handle coHost1 update or creation
  if (data.coHost1Phone) {
    const existingUser = await User.findOne({ phoneNumber: data.coHost1Phone });
    if (existingUser) {
      coHostId1 = existingUser._id;
    } else {
      const newUser = new User({
        fullName: data.coHost1Name || "",
        phoneNumber: data.coHost1Phone,
        registrationDate: new Date(),
      });
      const newUserData = await newUser.save();
      coHostId1 = newUserData._id;
    }
  }

  // Handle coHost2 update or creation
  if (data.coHost2Phone) {
    const existingUser = await User.findOne({ phoneNumber: data.coHost2Phone });
    if (existingUser) {
      coHostId2 = existingUser._id;
    } else {
      const newUser = new User({
        fullName: data.coHost2Name || "",
        phoneNumber: data.coHost2Phone,
        registrationDate: new Date(),
      });
      const newUserData = await newUser.save();
      coHostId2 = newUserData._id;
    }
  }

  // Prepare updated data
  const updatedData = {
    tournamentStartDateTime: userStartDate,
    tournamentEndDateTime: userEndDate,
    tournamentName: data.tournamentName,
    tournamentCategory: { name: data.tournamentCategory },
    ballType: { name: data.ballType },
    pitchType: { name: data.pitchType },
    email: userInfo.email,
    matchType: { name: data.matchType },
    tournamentPrize: { name: data.tournamentPrize },
    rules: data.rules,
    disclaimer: data.disclaimer,
    fees: data.fees,
    ballCharges: data.ballCharges,
    breakfastCharges: data.breakfastCharges,
    stadiumAddress: data.stadiumAddress,
    tournamentLimit: data.tournamentLimit,
    gameType: { name: data.gameType },
    coverPhoto: imagePath,
    locationHistory: {
      point: {
        type: "Point",
        coordinates: [parseFloat(data.longitude), parseFloat(data.latitude)],
      },
      selectLocation: data.selectLocation,
    },
    user: userInfo.userId,
    coHostId1: coHostId1,
    coHostId2: coHostId2,
  };

  // Update tournament data in the database
  const updatedTournament = await Tournament.findByIdAndUpdate(tournamentId, updatedData, {
    new: true,
  });

  if (!updatedTournament) {
    throw CustomErrorHandler.notFound("Tournament not found.");
  }

  // Send notifications to registered teams about the update
  const notificationData = {
    title: "Gully Team",
    body: `${tournament.tournamentName} Tournament has been updated! Check the changes in the app.`,
    image: "",
  };

  const registeredTeams = await RegisteredTeam.find({
    tournament: tournamentId,
    status: "Accepted",
  });

  const notificationPromises = registeredTeams.map((team) => {
    if (team.user?.fcmToken) {
      return firebaseNotification.sendNotification(team.user.fcmToken, notificationData);
    }
  });

  try {
    await Promise.all(notificationPromises);
    console.log("Notifications sent successfully.");
  } catch (error) {
    console.error("Error sending notifications:", error);
  }

  return updatedTournament;
},

  // async editTournament(data, userStartDate, userEndDate, TournamentId) {
  //   const userInfo = global.user;

  //   let tournamentImage = await Tournament.findOne({ TournamentId });

  //   let imagePath;
  //   if (data.coverPhoto) {
  //     imagePath = await ImageUploader.Upload(
  //       data.coverPhoto,
  //       "tournament",
  //       tournamentImage.coverPhoto,
  //     );
  //   } else {
  //     imagePath = tournamentImage.coverPhoto;
  //   }

  //   let coHostId1;
  //   let coHostId2;

  //   if (data.coHost1Phone) {
  //     const existingUser = await User.exists({
  //       phoneNumber: data.coHost1Phone,
  //     });

  //     if (existingUser) {
  //       coHostId1 = existingUser._id;
  //     } else {
  //       const newUser = new User({
  //         fullName: data.coHost1Name,
  //         phoneNumber: data.coHost1Phone,
  //         registrationDate: new Date(),
  //       });

  //       const newUserData = await newUser.save();
  //       coHostId1 = newUserData._id;
  //     }
  //   }

  //   if (data.coHost2Phone) {
  //     const existingUser = await User.exists({
  //       phoneNumber: data.coHost2Phone,
  //     });

  //     if (existingUser) {
  //       coHostId2 = existingUser._id;
  //     } else {
  //       const newUser = new User({
  //         fullName: data.coHost2Name,
  //         phoneNumber: data.coHost2Phone,
  //         registrationDate: new Date(),
  //       });

  //       const newUserData = await newUser.save();
  //       coHostId2 = newUserData._id;
  //     }
  //   }

  //   // Update data
  //   const updatedData = {
  //     tournamentStartDateTime: userStartDate,
  //     tournamentEndDateTime: userEndDate,
  //     tournamentName: data.tournamentName,
  //     tournamentCategory: { name: data.tournamentCategory },
  //     ballType: { name: data.ballType },
  //     pitchType: { name: data.pitchType },
  //     email: userInfo.email,
  //     matchType: { name: data.matchType },
  //     tournamentPrize: { name: data.tournamentPrize },
  //     rules: data.rules,
  //     disclaimer: data.disclaimer,
  //     fees: data.fees,
  //     ballCharges: data.ballCharges,
  //     breakfastCharges: data.breakfastCharges,
  //     stadiumAddress: data.stadiumAddress,
  //     tournamentLimit: data.tournamentLimit,
  //     gameType: { name: data.gameType },
  //     coverPhoto: imagePath,
  //     locationHistory: {
  //       point: {
  //         type: "Point",
  //         coordinates: [parseFloat(data.longitude), parseFloat(data.latitude)],
  //       },
  //       selectLocation: data.selectLocation,
  //     },
  //     user: userInfo.userId,
  //     coHostId1: coHostId1,
  //     coHostId2: coHostId2,
  //   };

  //   // Use findByIdAndUpdate to update the tournament
  //   const updatedTournament = await Tournament.findByIdAndUpdate(
  //     TournamentId,
  //     updatedData,
  //     { new: true },
  //   );

  //   // Check if the tournament was found and updated
  //   if (!updatedTournament) {
  //     // Handle the case where the tournament is not found
  //     throw CustomErrorHandler.notFound("Tournament Not Found");
  //   }

  //   //notification
  //   const notificationData = {
  //     title: "Gully Team",
  //     body: `${tournamentImage.tournamentName} Tournament has been Change.! please check your email for more details.`,
  //     image: "",
  //   };

  //   const notificationPromises = [];

  //   //find all the registere Team in that tournament to notify about change in tournament.
  //   const registeredTeam = await RegisteredTeam.find({
  //     tournament: TournamentId,
  //     status: "Accepted",
  //   });

  //   registeredTeam.forEach(async function (team) {
  //     if (team && team.user && team.user.fcmToken) {
  //       notificationPromises.push(
  //         firebaseNotification.sendNotification(
  //           team?.user?.fcmToken,
  //           notificationData,
  //         ),
  //       );
  //     }
  //   });

  //   try {
  //     await Promise.all(notificationPromises);
  //     console.log("Notifications sent successfully");
  //   } catch (error) {
  //     console.error("Error sending notifications:", error);
  //   }

  //   return updatedTournament;
  // },

  async getTournament(data) {
    const { latitude, longitude, startDate, filter } = data;

    console.log("startDate", startDate);

    let startDateTime, endDateTime;

    let currentDate = new Date();
    let formattedDate = currentDate.toISOString().split("T")[0];

    let checkcondition = false;

    if (filter === "past") {
      // If startDate and endDate are not provided, get tournaments for the past 7 days, current date, and future 7 days
      startDateTime = new Date(`${formattedDate}T00:00:00.000Z`);
      startDateTime.setDate(startDateTime.getDate() - 7);

      endDateTime = new Date(`${formattedDate}T23:59:59.999Z`);
    } else if (filter === "upcoming") {
      // If startDate and endDate are not provided, get tournaments for the past 7 days, current date, and future 7 days
      startDateTime = new Date(`${formattedDate}T00:00:00.000Z`);
      startDateTime.setDate(startDateTime.getDate());

      endDateTime = new Date(`${formattedDate}T23:59:59.999Z`);
      endDateTime.setDate(endDateTime.getDate() + 7);
    } else if (startDate) {
      checkcondition = true;

      startDateTime = new Date(`${startDate}T00:00:00.000Z`);
      endDateTime = new Date(`${startDate}T23:59:59.999Z`);
      // endDateTime.setDate(endDateTime.getDate() - 1);
    } else {
      startDateTime = new Date(`${formattedDate}T00:00:00.000Z`);
      endDateTime = new Date(`${formattedDate}T23:59:59.999Z`);
    }

    //     let currentDate = new Date();
    // let formattedDate = currentDate.toISOString().split('T')[0];
    //     }
    //     startDateTime = new Date(`${formattedDate}T00:00:00.000Z`);
    //     //to get tournament of same day i am convertin enddate to the same date
    //     endDateTime = new Date(`${formattedDate}T23:59:59.999Z`);
    //     endDateTime.setDate(endDateTime.getDate() -1);

    console.log("startDateTime", startDateTime);
    console.log("endDateTime", endDateTime);
    console.log("latitude", latitude);
    console.log("longitude", longitude);

    let orCondition = [
      {
        tournamentStartDateTime: {
          $gte: startDateTime,
          $lt: endDateTime,
        },
      },
      {
        tournamentEndDateTime: {
          $gte: startDateTime,
          $lt: endDateTime,
        },
      },
    ];

    // for current Tournament
    // Condition to use $or or an empty array based on a certain condition
    if (checkcondition || filter == "current") {
      orCondition = [
        {
          tournamentStartDateTime: {
            $lte: startDateTime,
          },
          tournamentEndDateTime: {
            $gte: endDateTime,
          },
        },
      ];
    }

    // for Past Tournament
    // if ( filter=="past") {
    //   orCondition = [
    //     {
    //       tournamentStartDateTime: {
    //         $lt: endDateTime,
    //       },
    //     },
    //   ];
    // }

    let tournament_data = await Tournament.aggregate([
      {
        $geoNear: {
          near: {
            type: "Point",
            coordinates: [longitude, latitude],
          },
          distanceField: "distance",
          spherical: true,
          // maxDistance: parseFloat(10) * 10000, // Convert kilometers to meters 10km * 1000m
          query: {
            isDeleted: false,
            isActive: true,
            $or: orCondition,
            // $or: [
            //   {
            //     tournamentStartDateTime: {
            //       $gte: startDateTime,
            //       $lt: endDateTime,
            //     },
            //   },
            //   {
            //     tournamentEndDateTime: {
            //       $gte: startDateTime,
            //       $lt: endDateTime,
            //     },
            //   },

            //   {
            //     tournamentStartDateTime: {
            //       $lte: startDateTime, // Start date is less than or equal to the current date
            //     },
            //     tournamentEndDateTime: {
            //       $gte: endDateTime, // End date is greater than or equal to the current date
            //     },
            //   },
            // ],
          },
          // key: "locationHistory.currentLocation.coordinates",
        },
      },
      {
        $addFields: {
          distanceInKm: {
            $divide: ["$distance", 1000],
          },
        },
      },
      {
        $match: {
          distanceInKm: { $lt: 10 }, // Adjust as needed 3000 meaks 3km
        },
      },
      {
        $lookup: {
          from: "registeredteams",
          foreignField: "tournament",
          localField: "_id",
          as: "registeredTeams",
        },
      },
      {
        $addFields: {
          //It is Accepted Team Count
          registeredTeamsCount: {
            $size: {
              $filter: {
                input: "$registeredTeams",
                as: "registeredTeam",
                cond: { $eq: ["$$registeredTeam.status", "Accepted"] },
              },
            },
          },
          pendingTeamsCount: {
            $size: {
              $filter: {
                input: "$registeredTeams",
                as: "registeredTeam",
                cond: { $eq: ["$$registeredTeam.status", "Pending"] },
              },
            },
          },

          // isFull:
          //   $gte: ["$tournamentLimit", { $size: "$registeredTeams" }],
          // },
          timeLeft: {
            $max: [
              0,
              {
                $ceil: {
                  $divide: [
                    {
                      $subtract: ["$tournamentStartDateTime", new Date()],
                    },
                    1000 * 60 * 60 * 24, // Convert milliseconds to days
                  ],
                },
              },
            ],
          },
        },
      },
      {
        $lookup: {
          from: "matches",
          foreignField: "tournament",
          localField: "_id",
          as: "matches",
          pipeline: [
            {
              $match: {
                dateTime: {
                  $gte: startDateTime,
                  $lt: endDateTime,
                },
              },
            },
            {
              $lookup: {
                from: "teams",
                foreignField: "_id",
                localField: "team1",
                as: "team1",
              },
            },
            {
              $lookup: {
                from: "tournaments",
                foreignField: "_id",
                localField: "tournament",
                as: "tournament",
              },
            },
            {
              $lookup: {
                from: "teams",
                foreignField: "_id",
                localField: "team2",
                as: "team2",
              },
            },
            {
              $addFields: {
                "team1.players": [],
                "team2.players": [],
              },
            },
            {
              $unwind: {
                path: "$team1",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $unwind: {
                path: "$team2",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $unwind: {
                path: "$tournament",
                preserveNullAndEmptyArrays: true,
              },
            },
            {
              $addFields: {
                tournamentName: "$tournament.tournamentName",
                tournamentId: "$tournament._id",
              },
            },
            {
              $project: {
                tournament: 0,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "users",
          foreignField: "_id",
          localField: "user",
          as: "user",
          pipeline: [
            {
              $project: {
                _id: 1,
                fullName: 1,
                phoneNumber: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$user",
          preserveNullAndEmptyArrays: true,
        },
      },

      {
        $addFields: {
          organizerName: "$user.fullName",
          phoneNumber: "$user.phoneNumber",
        },
      },
      {
        $sort: {
          tournamentStartDateTime: 1, // Sort by fieldName1 in ascending order
          // fieldName2: -1 // Sort by fieldName2 in descending order
        },
      },
      // {
      //   $project: {
      //     distance: 0,
      //   },
      // },
    ]);
    // console.log("tournament_data", tournament_data);

    const matches = tournament_data.map((tournament) => tournament.matches);
    return { tournament_data, matches: matches.flat(1) };
  },

  async getTournamentByName(query) {
    let tournament_data = await Tournament.aggregate([
      {
        $match: {
          $text: { $search: query },
        },
      },
      {
        $match: {
          //user: new Types.ObjectId(userInfo.userId),
          isDeleted: false,
          isCompleted: false,
          isActive: true,
          //tournamentEndDateTime: { $gt: currentDate },
        },
      },
      {
        $lookup: {
          from: "registeredteams",
          foreignField: "tournament",
          localField: "_id",
          as: "registeredTeams",
        },
      },
      {
        $addFields: {
          //It is Accepted Team Count
          registeredTeamsCount: {
            $size: {
              $filter: {
                input: "$registeredTeams",
                as: "registeredTeam",
                cond: { $eq: ["$$registeredTeam.status", "Accepted"] },
              },
            },
          },
          pendingTeamsCount: {
            $size: {
              $filter: {
                input: "$registeredTeams",
                as: "registeredTeam",
                cond: { $eq: ["$$registeredTeam.status", "Pending"] },
              },
            },
          },

          // isFull:
          //   $gte: ["$tournamentLimit", { $size: "$registeredTeams" }],
          // },
          timeLeft: {
            $max: [
              0,
              {
                $ceil: {
                  $divide: [
                    {
                      $subtract: ["$tournamentStartDateTime", new Date()],
                    },
                    1000 * 60 * 60 * 24, // Convert milliseconds to days
                  ],
                },
              },
            ],
          },
        },
      },

      {
        $lookup: {
          from: "users",
          foreignField: "_id",
          localField: "user",
          as: "user",
          pipeline: [
            {
              $project: {
                _id: 1,
                fullName: 1,
                phoneNumber: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$user",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $addFields: {
          organizerName: "$user.fullName",
          phoneNumber: "$user.phoneNumber",
        },
      },
      // {
      //   $project: {
      //     distance: 0,
      //   },
      // },
      // Other stages of your aggregation pipeline
    ]);

    return tournament_data;
  },

  //to get current Tournament Created by organizer
  async getCurrentTournamentByOrganizer() {
    let userInfo = global.user;
    const currentDate = new Date();

    let TournamentData = await Tournament.aggregate([
      {
        $match: {
          $or: [
            { user: new Types.ObjectId(userInfo.userId) },
            { coHostId1: new Types.ObjectId(userInfo.userId) },
            { coHostId2: new Types.ObjectId(userInfo.userId) }, // New condition for coHostId2
          ],
          isDeleted: false,
          isCompleted: false,
          isActive: true,
          tournamentEndDateTime: { $gt: currentDate },
        },
      },
      {
        $lookup: {
          from: "registeredteams",
          foreignField: "tournament",
          localField: "_id",
          as: "registeredTeams",
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "user",
          foreignField: "_id",
          as: "user",
          pipeline: [
            {
              $project: {
                _id: 1,
                fullName: 1,
                phoneNumber: 1,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "coHostId1",
          foreignField: "_id",
          as: "coHost1",
          pipeline: [
            {
              $project: {
                _id: 1,
                fullName: 1,
                phoneNumber: 1,
              },
            },
          ],
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "coHostId2",
          foreignField: "_id",
          as: "coHost2",
          pipeline: [
            {
              $project: {
                _id: 1,
                fullName: 1,
                phoneNumber: 1,
              },
            },
          ],
        },
      },
      {
        $unwind: {
          path: "$user",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$coHost1",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $unwind: {
          path: "$coHost2",
          preserveNullAndEmptyArrays: true,
        },
      },
      {
        $addFields: {
          //It is Accepted Team Count
          registeredTeamsCount: {
            $size: {
              $filter: {
                input: "$registeredTeams",
                as: "registeredTeam",
                cond: { $eq: ["$$registeredTeam.status", "Accepted"] },
              },
            },
          },
          pendingTeamsCount: {
            $size: {
              $filter: {
                input: "$registeredTeams",
                as: "registeredTeam",
                cond: { $eq: ["$$registeredTeam.status", "Pending"] },
              },
            },
          },
        },
      },
    ]);

    if (!TournamentData) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("Team Not Found");
    }
    return TournamentData;
  },

  async deleteTournament(TournamentId) {
    // Find the tournament by ID
    const tournament = await Tournament.findById(TournamentId);

    if (!tournament) {
      // Handle the case where the tournament is not found
      throw CustomErrorHandler.notFound("tournament Not Found");
    }

    // Update the tournament's isDeleted is true;
    tournament.isDeleted = true;
    // Save the updated user document
    let tournamentdata = await tournament.save();
    return tournamentdata;
  },
  async createEntryForm(teamID, tournamentID) {
    const userInfo = global.user;
  
    // Fetch the team details
    const team = await Team.findById(teamID);
  
    if (team.players.length < 11) {
      throw CustomErrorHandler.badRequest("Team Member is Insufficient");
    }
  
    // Create a new entry form
    const entryForm = new EntryForm({
      captainId: userInfo.userId,
      team: teamID,
    });
  
    // Check if the team already exists in the tournament
    const teamExist = await RegisteredTeam.exists({
      team: teamID,
      tournament: tournamentID,
    });
  
    if (teamExist) {
      const registeredTeam = await RegisteredTeam.findOne({
        tournament: tournamentID,
        team: teamID,
        status: "Denied",
      });
  
      if (registeredTeam) {
        registeredTeam.status = "Pending";
        await registeredTeam.save();
      } else {
        throw CustomErrorHandler.badRequest("Team Already Exist");
      }
    } else {
      const registeredTeam = new RegisteredTeam({
        team: teamID,
        user: userInfo.userId,
        tournament: tournamentID,
      });
  
      await registeredTeam.save();
      await entryForm.save();
    }
  
    // Send notification to the tournament organizer
    const tournament = await Tournament.findById(tournamentID).populate("organizer");
    const organizer = tournament.organizer;
  
    if (organizer?.fcmToken) {
      const notificationData = {
        title: "Gully Team",
        body: `${team.teamName} has sent you a join request for the ${tournament.tournamentName} tournament.`,
      };
  
      console.log("Sending notification to organizer with token:", organizer.fcmToken);  // Log the FCM token
  
      try {
        const response = await firebaseNotification.sendNotification(organizer.fcmToken, notificationData);
        console.log("Notification sent to the organizer successfully:", response);
      } catch (error) {
        console.error("Error sending notification:", error);
      }
    } else {
      console.error("No FCM token found for the organizer.");
    }
  
    return entryForm;
  },
  

  // async createEntryForm(teamID, tournamentID) {
  //   const userInfo = global.user;

  //   const team = await Team.findById(teamID);

  //   console.log(team.players.length);

  //   if (team.players.length < 11) {
  //     throw CustomErrorHandler.badRequest("Team Member is Insufficient");
  //   }

  //   const entryForm = new EntryForm({
  //     captainId: userInfo.userId,
  //     team: teamID,
  //   });

  //   // Save the new HelpdeskTicket and wait for the operation to complete

  //   // const tournament = await Tournament.findById(tournamentID);

  //   const teamExist = await RegisteredTeam.exists({
  //     team: teamID,
  //     tournament: tournamentID,
  //   });

  //   if (teamExist) {
  //     const registeredTeam = await RegisteredTeam.findOne({
  //       tournament: tournamentID,
  //       team: teamID,
  //       status: "Denied",
  //     });

  //     if (registeredTeam) {
  //       registeredTeam.status = "Pending";
  //       registeredTeam.save();
  //     } else {
  //       throw CustomErrorHandler.badRequest("Team Already Exist");
  //     }
  //   } else {
  //     const registeredTeam = new RegisteredTeam({
  //       team: teamID,
  //       user: userInfo.userId,
  //       tournament: tournamentID,
  //     });

  //     await registeredTeam.save();
  //     await entryForm.save();
  //   }
  //   return entryForm;
  // },

  async teamRequest(tournamentID, status) {
    const userInfo = global.user;

    const tournament_data = await RegisteredTeam.find({
      tournament: tournamentID,
      status: status,
    });

    return { tournament_data };
  },

  async updateTeamRequest(teamID, tournamentID, action) {
    const userInfo = global.user;

    const registeredTeam = await RegisteredTeam.findOne({
      tournament: tournamentID,
      team: teamID,
      status: "Pending",
    });

    const tournament = await Tournament.findById(tournamentID);

    if (tournament?.authority != userInfo.userId) {
      throw CustomErrorHandler.badRequest("You do not have permission.");
    }

    if (!registeredTeam) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("tournament or team Not Found");
    }
    const acceptedTeamCount = await RegisteredTeam.count({
      tournament: tournamentID,
      status: "Accepted",
    });

    if (action == "Accepted") {
      if (acceptedTeamCount >= registeredTeam.tournament.tournamentLimit) {
        throw CustomErrorHandler.notFound("Tournament Already Full.");
      }
    }

    registeredTeam.status = action;
    registeredTeam.save();

    //notification

    const captainUserId = registeredTeam.user._id.toString();

    const user = await User.findOne({ _id: captainUserId }).select("fcmToken");

    if (user) {
      if (user?.fcmToken) {
        const notificationData = {
          title: "Gully Team",
          body: `${action == "Accepted" ? "Congratulations!" : "Oops !"} Your registration for the ${tournament?.tournamentName} tournament is ${action}.🏆`,
          image: "",
        };

        await firebaseNotification.sendNotification(
          user?.fcmToken,
          notificationData,
        );
      }
    }

    return registeredTeam;
  },

  async getCount() {
    const userInfo = global.user;

    // Fetch all tournaments
    const allTournaments = await Tournament.find({
      user: userInfo.userId,
      isDeleted: false,
      isCompleted: false,
      isActive: true,
    });

    // Iterate through all tournaments and accumulate counts
    const totalPendingTeams = await RegisteredTeam.count({
      status: "Pending",
      tournament: { $in: allTournaments },
    });
    const totalRegisteredTeams = await RegisteredTeam.count({
      tournament: { $in: allTournaments },
    });
    const totalAcceptedTeams = await RegisteredTeam.count({
      status: "Accepted",
      tournament: { $in: allTournaments },
    });
    let data = {
      totalPendingTeams,
      totalAcceptedTeams,
      currentTournamentCount: allTournaments.length,
    };

    return data;
  },

  async getTournamentByUser() {
    const userInfo = global.user;

    // Fetch all tournaments
    const allTournaments = await Tournament.find({
      $or: [
        { user: userInfo.userId },
        { coHostId1: userInfo.userId },
        { coHostId2: userInfo.userId }, // New condition for coHostId2
      ],
      isDeleted: false,
      isCompleted: false,
      isActive: true,
    });

    // Iterate through all tournaments and accumulate counts
    const totalPendingTeams = await RegisteredTeam.count({
      status: "Pending",
      tournament: { $in: allTournaments },
    });
    const totalRegisteredTeams = await RegisteredTeam.count({
      tournament: { $in: allTournaments },
    });
    const totalAcceptedTeams = await RegisteredTeam.count({
      status: "Accepted",
      tournament: { $in: allTournaments },
    });
    let data = {
      totalPendingTeams,
      totalAcceptedTeams,
      currentTournamentCount: allTournaments.length,
    };

    return data;
  },

  async updateAutority(tournamentID, UserId) {
    const tournament = await Tournament.findById(tournamentID).select("user");

    if (!tournament) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("tournament Not Found");
    }

    console.log("organizer id", tournament.user);
    console.log("User id", global.user.userId);

    if (tournament.user != global.user.userId) {
      throw CustomErrorHandler.badRequest("You are not allowed to change.");
    }

    tournament.authority = UserId;
    await tournament.save();

    return UserId;
  },

  // ***********************    admin releated services     ****************************

  async getAllTournament(pageSize, skip, search) {
    // Query to count the total number of subadmins
    const totalTournament = await Tournament.countDocuments({ isActive: true });

    const aggregationPipeline = [];

    // Match stage for search
    if (search) {
      aggregationPipeline.push({
        $match: {
          $or: [{ tournamentName: { $regex: search, $options: "i" } }],
        },
      });
    }

    // Match stage for isActive
aggregationPipeline.push({
  $match: {
    isActive: true
  }
});
    // Skip and Limit stages
    if (!search) {
      aggregationPipeline.push({ $skip: skip });
      aggregationPipeline.push({ $limit: pageSize });
    }

    aggregationPipeline.push(
      {
        $lookup: {
          from: "users", // assuming the user model is named 'users'
          localField: "user",
          foreignField: "_id",
          as: "user",
        },
      },
      {
        $unwind: "$user",
      },
      {
        $project: {
          _id: 1,
          tournamentName: 1,
          tournamentStartDateTime: 1, // include specific tournament fields
          tournamentEndDateTime: 1, // include specific tournament fields
          stadiumAddress: 1,
          email: 1,
          isDeleted: 1,
          isCompleted: 1,
          fees: 1,
          gameType: "$gameType.name",
          phoneNumber: "$user.phoneNumber",
          fullName: "$user.fullName",
          locations: { $arrayElemAt: ["$user.locations.placeName", 0] },
        },
      },
    );

    const tournament = await Tournament.aggregate(aggregationPipeline);

    // const tournament = await Tournament.aggregate([
    //   {
    //     $skip: skip,
    //   },
    //   {
    //     $limit: pageSize,
    //   },
    //   {
    //     $lookup: {
    //       from: "users", // assuming the user model is named 'users'
    //       localField: "user",
    //       foreignField: "_id",
    //       as: "user",
    //     },
    //   },
    //   {
    //     $unwind: "$user",
    //   },
    //   {
    //     $project: {
    //       _id: 1,
    //       tournamentName: 1,
    //       tournamentStartDateTime: 1, // include specific tournament fields
    //       tournamentEndDateTime: 1, // include specific tournament fields
    //       stadiumAddress: 1,
    //       email: 1,
    //       isDeleted: 1,
    //       isCompleted: 1,
    //       fees: 1,
    //       gameType: "$gameType.name",
    //       phoneNumber: "$user.phoneNumber",
    //       fullName: "$user.fullName",
    //       locations: { $arrayElemAt: ["$user.locations.placeName", 0] },
    //     },
    //   },
    // ]);

    return {
      data: tournament,
      count: totalTournament,
    };
  },

  async getAllTournamentLive(pageSize, skip) {
    const currentDate = new Date();
    let startDateTime, endDateTime;
    startDateTime = new Date(currentDate);
    startDateTime.setHours(0, 0, 0, 0); // Set time to midnight
    endDateTime = new Date(currentDate);
    endDateTime.setHours(23, 59, 59, 999);

    // let startDate = "2024-02-13";
    // let endDate = "2024-02-17";

    // console.log("startDateTime",startDateTime);
    // console.log("endDateTime",endDateTime);

    // startDateTime = new Date(`${startDate}T00:00:00.000Z`);
    // endDateTime = new Date(`${endDate}T23:59:59.999Z`);

    // Query to count the total number of subadmins
    const totalTournament = await Tournament.countDocuments();

    // const tournament = await Tournament.find({
    //   isDeleted: false,
    //   $or: [
    //     {
    //       tournamentStartDateTime: {
    //         $gte: startDateTime,
    //         $lt: endDateTime,
    //       },
    //     },
    //     {
    //       tournamentEndDateTime: {
    //         $gte: startDateTime,
    //         $lt: endDateTime,
    //       },
    //     },
    //   ],
    // })
    //   .skip(skip)
    //   .limit(pageSize)
    //   .populate({
    //     path: 'user',
    //     select: 'email phoneNumber fullName locations.placeName',
    //   });

    const tournament = await Tournament.aggregate([
      {
        $match: {
          isDeleted: false,
          $or: [
            {
              tournamentStartDateTime: {
                $gte: startDateTime,
                $lt: endDateTime,
              },
            },
            {
              tournamentEndDateTime: {
                $gte: startDateTime,
                $lt: endDateTime,
              },
            },
          ],
        },
      },
      {
        $skip: skip,
      },
      {
        $limit: pageSize,
      },
      {
        $lookup: {
          from: "users",
          localField: "user",
          foreignField: "_id",
          as: "user",
        },
      },
      {
        $unwind: "$user",
      },
      {
        $project: {
          _id: 1,
          tournamentName: 1,
          tournamentStartDateTime: 1,
          tournamentEndDateTime: 1,
          stadiumAddress: 1,
          email: 1,
          isDeleted: 1,
          isCompleted: 1,
          fees: 1,
          gameType: "$gameType.name",
          phoneNumber: "$user.phoneNumber",
          fullName: "$user.fullName",
          locations: { $arrayElemAt: ["$user.locations.placeName", 0] },
        },
      },
    ]);

    return {
      data: tournament,
      count: totalTournament,
    };
  },

  async getTournamentById(Id) {
    // Query to retrieve subadmins for the current page
    let tournament = await Tournament.find({ _id: Id }).populate({
      path: "user",
      select: "email phoneNumber fullName locations.placeName", // Replace with the actual fields you want to include
    }); // Limit the number of documents per page

    let tournamentData = tournament.map((entry) => ({
      tournamentName: entry.tournamentName,
      ballCharges: entry.ballCharges,
      ballType: entry.ballType.name,
      fees: entry.fees,
      gameType: entry.gameType.name,
      pitchType: entry.pitchType.name,
      matchType: entry.matchType.name,
      breakfastCharges: entry.breakfastCharges,
      // latestLocation: entry.locationHistory.currentLocation.selectLocation,
      stadiumAddress: entry.stadiumAddress,
      tournamentCategory: entry.tournamentCategory.name,
      tournamentStartDateTime: moment(entry.tournamentStartDateTime).format(
        "DD-MM-YYYY",
      ),
      tournamentEndDateTime: moment(entry.tournamentEndDateTime).format(
        "DD-MM-YYYY",
      ),
      tournamentLimit: entry.tournamentLimit,
      tournamentPrize: entry.tournamentPrize.name,
    }));

    return tournamentData[0];
  },

  async getMatchesByTournamentId(TournamentId) {
    // let startDate = "2024-02-13";
    // let endDate = "2024-02-17";

    const currentDate = new Date();
    let startDateTime, endDateTime;
    startDateTime = new Date(currentDate);
    startDateTime.setHours(0, 0, 0, 0); // Set time to midnight
    endDateTime = new Date(currentDate);
    endDateTime.setHours(23, 59, 59, 999);

    // startDateTime = new Date(`${startDate}T00:00:00.000Z`);
    // endDateTime = new Date(`${endDate}T23:59:59.999Z`);

    const Matches = await Match.find({
      tournament: TournamentId,
      // $or: [
      //   {
      //     dateTime: {
      //       $gte: startDateTime,
      //       $lt: endDateTime,
      //     },
      //   },
      // ],
    }).select("_id tournament status team1 team2");

    // const tournament = await Tournament.aggregate([
    //   {
    //     $match: {
    //       isDeleted: false,
    //       $or: [
    //         {
    //           tournamentStartDateTime: {
    //             $gte: startDateTime,
    //             $lt: endDateTime,
    //           },
    //         },
    //         {
    //           tournamentEndDateTime: {
    //             $gte: startDateTime,
    //             $lt: endDateTime,
    //           },
    //         },
    //       ],
    //     },
    //   },
    //   {
    //     $skip: skip,
    //   },
    //   {
    //     $limit: pageSize,
    //   },
    //   {
    //     $lookup: {
    //       from: "users",
    //       localField: "user",
    //       foreignField: "_id",
    //       as: "user",
    //     },
    //   },
    //   {
    //     $unwind: "$user",
    //   },
    //   {
    //     $project: {
    //       _id: 1,
    //       tournamentName: 1,
    //       tournamentStartDateTime: 1,
    //       tournamentEndDateTime: 1,
    //       stadiumAddress: 1,
    //       email: 1,
    //       isDeleted: 1,
    //       isCompleted: 1,
    //       fees: 1,
    //       gameType: "$gameType.name",
    //       phoneNumber: "$user.phoneNumber",
    //       fullName: "$user.fullName",
    //       locations: { $arrayElemAt: ["$user.locations.placeName", 0] },
    //     },
    //   },
    // ]);

    return Matches;
  },

  async updateTournamentById(TournamentId, data) {
    const userInfo = global.user;
    // Update data
    const updatedData = {
      tournamentName: data.tournamentName,
      ballCharges: data.ballCharges,
      ballType: { name: data.ballType },
      breakfastCharges: data.breakfastCharges,
      fees: data.fees,
      matchType: { name: data.matchType },
      pitchType: { name: data.pitchType },
      tournamentCategory: { name: data.tournamentCategory },

      tournamentStartDateTime: new Date(
        data.tournamentStartDateTime.replace(
          /(\d{2})-(\d{2})-(\d{4})/,
          "$3-$2-$1T00:00:00.000Z",
        ),
      ),
      tournamentEndDateTime: new Date(
        data.tournamentEndDateTime.replace(
          /(\d{2})-(\d{2})-(\d{4})/,
          "$3-$2-$1T00:00:00.000Z",
        ),
      ),
      tournamentPrize: { name: data.tournamentPrize },
    };

    // Use findByIdAndUpdate to update the tournament
    const updatedTournament = await Tournament.findByIdAndUpdate(
      TournamentId,
      updatedData,
      { new: true },
    );

    // Check if the tournament was found and updated
    if (!updatedTournament) {
      // Handle the case where the tournament is not found
      throw CustomErrorHandler.notFound("Tournament Not Found");
    }

    return updatedTournament;
  },

  async getMatchesHistoryByTournamentId(TournamentId) {
    
    const Match = await Match.find({
      tournament: TournamentId,
      
    }).select("_id tournament status team1 team2");

    
    return Match;
  },

  //DG
  // async eliminateTeamAndProgress(tournamentId, eliminatedTeamId, round){
  //   // Step 1: Find the tournament and matches
  //   const tournament = await Tournament.findById(tournamentId).populate("matches");
  //   if (!tournament) {
  //     throw new Error("Tournament not found");
  //   }
  
  //   const matchesInRound = await Match.find({
  //     tournament: tournamentId,
  //     Round: round,
  //   });
  
  //   if (!matchesInRound || matchesInRound.length === 0) {
  //     throw new Error("No matches found in this round");
  //   }
  
  //   // Step 2: Mark the team as eliminated and declare match winners
  //   const markTeamAsEliminated = async () => {
  //     let validElimination = false;
  
  //     for (const match of matchesInRound) {
  //       if (match.team1.equals(eliminatedTeamId) || match.team2.equals(eliminatedTeamId)) {
  //         match.eliminated = true;
  //         match.winningTeamId = match.team1.equals(eliminatedTeamId)
  //           ? match.team2
  //           : match.team1;
  //         await match.save();
  //         validElimination = true;
  //         break;
  //       }
  //     }
  //     return validElimination;
  //   };
  
  //   const validElimination = await markTeamAsEliminated();
  //   if (!validElimination) {
  //     throw new Error("Eliminated team not found in this round");
  //   }
  
  //   // Step 3: Get remaining teams
  //   const getRemainingTeams = async () => {
  //     const matches = await Match.find({
  //       tournament: tournamentId,
  //       eliminated: false,
  //     }).populate("team1 team2");
  
  //     const remainingTeams = new Set();
  //     for (const match of matches) {
  //       if (!match.eliminated) {
  //         remainingTeams.add(match.team1._id.toString());
  //         remainingTeams.add(match.team2._id.toString());
  //       }
  //     }
  
  //     const teamIds = Array.from(remainingTeams);
  //     return await Team.find({ _id: { $in: teamIds } });
  //   };
  
  //   const remainingTeams = await getRemainingTeams();
  
  //   // Step 4: If only one team remains, declare the winner
  //   if (remainingTeams.length === 1) {
  //     tournament.isCompleted = true;
  //     await tournament.save();
  //     return { winner: remainingTeams[0] };
  //   }
  
  //   // Step 5: Create matches for the next round
  //   const createNextRoundMatches = async () => {
  //     const matches = [];
  //     for (let i = 0; i < remainingTeams.length; i += 2) {
  //       if (i + 1 < remainingTeams.length) {
  //         const match = new Match({
  //           tournament: tournamentId,
  //           team1: remainingTeams[i]._id,
  //           team2: remainingTeams[i + 1]._id,
  //           dateTime: new Date(), // Placeholder date
  //           Round: parseInt(round) + 1,
  //           matchNo: i / 2 + 1,
  //           status: "upcoming",
  //         });
  //         matches.push(match);
  //       }
  //     }
  //     await Match.insertMany(matches);
  //   };
  
  //   await createNextRoundMatches();
  
  //   return { success: true };
  // },

 

//   async  eliminateTeamsAndProgress(tournamentId, eliminatedTeamIds, round) {
//     try {
//         // Step 1: Fetch the tournament
//         const tournament = await Tournament.findById(tournamentId).populate("matches");
//         if (!tournament) {
//             throw new Error("Tournament not found");
//         }
  
//         // Step 2: Fetch matches for the given round
//         const matchesInRound = await Match.find({
//             tournament: tournamentId,
//             Round: round,
//         }).populate("team1 team2");
  
//         if (!matchesInRound || matchesInRound.length === 0) {
//             throw new Error("No matches found in this round");
//         }
  
//         // Step 3: Validate that eliminated teams are part of this round
//         const teamIdsInRound = new Set(
//             matchesInRound.flatMap((match) => [match.team1._id.toString(), match.team2._id.toString()])
//         );
  
//         const invalidTeamIds = eliminatedTeamIds.filter((id) => !teamIdsInRound.has(id));
//         if (invalidTeamIds.length > 0) {
//             throw new Error(`Invalid team IDs: ${invalidTeamIds.join(", ")} for round ${round}`);
//         }
  
//         // Step 4: Eliminate teams and update match winners
//         let validEliminations = false;
//         for (const match of matchesInRound) {
//             const team1Eliminated = eliminatedTeamIds.includes(match.team1._id.toString());
//             const team2Eliminated = eliminatedTeamIds.includes(match.team2._id.toString());
  
//             if (team1Eliminated || team2Eliminated) {
//                 match.eliminated = true;
//                 match.eliminatedRound = round;
  
//                 if (team1Eliminated && !team2Eliminated) {
//                     match.winningTeamId = match.team2._id;
//                 } else if (team2Eliminated && !team1Eliminated) {
//                     match.winningTeamId = match.team1._id;
//                 }
  
//                 await match.save();
//                 validEliminations = true;
//             }
//         }
  
//         if (!validEliminations) {
//             throw new Error("No valid teams found for elimination in this round");
//         }
  
//         // Step 5: Retrieve remaining teams
//         const activeMatches = await Match.find({
//             tournament: tournamentId,
//             eliminated: false,
//         }).populate("team1 team2");
  
//         const remainingTeams = new Set();
//         activeMatches.forEach((match) => {
//             if (match.team1 && match.team1._id) remainingTeams.add(match.team1._id.toString());
//             if (match.team2 && match.team2._id) remainingTeams.add(match.team2._id.toString());
//         });
  
//         // Validate remaining teams against the Team collection
//         const remainingTeamIds = Array.from(remainingTeams);
//         const teams = await Team.find({ _id: { $in: remainingTeamIds } });
  
//         if (teams.length === 0) {
//             throw new Error("No remaining teams found after elimination process.");
//         }
  
//         // Step 6: Declare winner if only one team remains
//         if (teams.length === 1) {
//             tournament.isCompleted = true;
//             await tournament.save();
  
//             return {
//                 success: true,
//                 message: "Tournament completed. Winner declared.",
//                 winner: {
//                     id: teams[0]._id,
//                     name: teams[0].teamName,
//                 },
//             };
//         }
  
//         // Step 7: Create matches for the next round
//         const nextRound = parseInt(round) + 1;
//         const newMatches = [];
//         for (let i = 0; i < teams.length; i += 2) {
//             if (i + 1 < teams.length) {
//                 newMatches.push({
//                     tournament: tournamentId,
//                     team1: teams[i]._id,
//                     team2: teams[i + 1]._id,
//                     dateTime: new Date(),
//                     Round: nextRound,
//                     matchNo: i / 2 + 1,
//                     status: "upcoming",
//                 });
//             }
//         }
  
//         if (newMatches.length > 0) {
//             await Match.insertMany(newMatches);
//         }
  
//         return {
//             success: true,
//             message: "Teams eliminated and retrieved reamining teams successfully",
//             data: {
//                 teamList: teams.map((team) => ({
//                     id: team._id,
//                     name: team.teamName,
//                 })),
//             },
//         };
//     } catch (error) {
//         return {
//             success: false,
//             message: "Server error",
//             error: error.message,
//         };
//     }
// },

//trial
async eliminateTeamsAndProgress(tournamentId, eliminatedTeamIds, round) {
  try {
      // Step 1: Fetch registered teams for the tournament
      const registeredTeams = await RegisteredTeam.find({
          tournament: tournamentId,
          status: "Accepted",
      });

      if (!registeredTeams.length) {
          throw new Error("No registered teams found for the given tournament.");
      }

      // Step 2: Validate that eliminated teams exist in the registered teams
      const validTeamIds = registeredTeams.map((team) => team.team.toString());
      const invalidTeamIds = eliminatedTeamIds.filter((id) => !validTeamIds.includes(id));
      if (invalidTeamIds.length > 0) {
          throw new Error(`Invalid team IDs: ${invalidTeamIds.join(", ")}`);
      }

      // Step 3: Update eliminated teams and matches for the round
      let validEliminations = false;
      const matchesInRound = await Match.find({ tournament: tournamentId, Round: round });

      for (const match of matchesInRound) {
          const team1Eliminated = eliminatedTeamIds.includes(match.team1.toString());
          const team2Eliminated = eliminatedTeamIds.includes(match.team2.toString());

          if (team1Eliminated || team2Eliminated) {
              match.eliminated = true;
              match.eliminatedRound = round;

              if (team1Eliminated && !team2Eliminated) {
                  match.winningTeamId = match.team2;
              } else if (team2Eliminated && !team1Eliminated) {
                  match.winningTeamId = match.team1;
              }

              await match.save();
              validEliminations = true;
          }
      }

      if (!validEliminations) {
          throw new Error("No valid teams found for elimination in this round.");
      }

      // Step 4: Retrieve remaining teams
      const remainingRegisteredTeams = await RegisteredTeam.find({
          tournament: tournamentId,
          _id: { $nin: eliminatedTeamIds },
          status: "Accepted",
      });

      if (remainingRegisteredTeams.length === 1) {
          // Tournament completed, declare winner
          return {
              winner: {
                  teamId: remainingRegisteredTeams[0].team,
                  teamName: remainingRegisteredTeams[0].teamName,
              },
          };
      }

      // Step 5: Schedule next round
      const nextRound = round + 1;
      const newMatches = [];
      for (let i = 0; i < remainingRegisteredTeams.length; i += 2) {
          if (i + 1 < remainingRegisteredTeams.length) {
              newMatches.push({
                  tournament: tournamentId,
                  team1: remainingRegisteredTeams[i].team,
                  team2: remainingRegisteredTeams[i + 1].team,
                  dateTime: new Date(),
                  Round: nextRound,
                  matchNo: Math.ceil((i + 1) / 2),
                  status: "upcoming",
              });
          }
      }

      if (newMatches.length > 0) {
          await Match.insertMany(newMatches);
      }

      return {
          remainingTeams: remainingRegisteredTeams.map((team) => ({
              teamId: team.team,
              teamName: team.teamName,
          })),
      };
  } catch (error) {
      console.error("Error eliminating teams:", error.message);
      throw new Error("Failed to eliminate teams and progress.");
  }
}


};

export default tournamentServices;
