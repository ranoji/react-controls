import { ObjectId } from "mongodb";
import { Types } from "mongoose";
import CustomErrorHandler from "../helpers/CustomErrorHandler.js";
import ImageUploader from "../helpers/ImageUploader.js";
import { Lookingfor, Player, Team, RegisteredTeam, User } from "../models/index.js";

import teamController from "../controllers/teamController.js";


const teamServices = {
  async getTeamById(TeamId) {
    //Find the Banner
    let teamData = await Team.findOne({ _id: TeamId });

    if (!teamData) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("Team Not Found");
    }

    let userData = await User.findOne({ _id: teamData.userId }); // Select the fields you need for the user

    // let captainData = {
    //   _id: userData._id,
    //   name: userData.fullName,
    //   email: userData.email,
    //   phoneNumber: userData.phoneNumber,
    //   role: "Captain",
    // };

    // push the captain data into the team data at index 0
    // teamData.players.unshift(captainData);

    return { teamData };
  },

  async getAllTeams() {
    //Find the Banner
    let teamData = await Team.find();

    if (!teamData) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("Team Not Found");
    }
    return teamData;
  },

  async getUserTeams() {
    //Find the Team
    const userInfo = global.user; 

    let teamData = await Team.find({ userId: userInfo.userId });

    if (!teamData) {
      // Handle the case where the Team is not found
      throw CustomErrorHandler.notFound("Team Not Found");
    }

    const modifiedTeamData = teamData.map((team) => {
      const playersCount = team.players.length;
      return {
        ...team.toObject(), // Convert Mongoose document to plain object
        playersCount,
      };
    });

    return modifiedTeamData;
  },
    
  async createTeam(data) {
    // Added fcmtoken for notifications
    const { teamLogo, teamName } = data;
    const userInfo = global.user;

    let imagePath = "";

    if (teamLogo) {
      imagePath = await ImageUploader.Upload(data.teamLogo, "create-team");
    }

    const team = new Team({
      teamLogo: imagePath,
      teamName: teamName,
      userId: userInfo.userId,
      // tournamentId: tournamentId,
    });

    let teamdata = await team.save();

    if (teamdata) {
      let user = await User.findById(userInfo.userId);

      const player = new Player({
        name: user.fullName,
        phoneNumber: user.phoneNumber,
        role: "Captain",
        team: teamdata._id,
        userId: userInfo.userId,
      });

      let playerData = await player.save();

      team.players.push(playerData._id);

      teamdata = await team.save();

      // for notification
      const fcmToken = user.fcmToken;

      return { teamdata, fcmToken };
    } 
  },
  async editTeam(data, TeamId) {
    const { teamLogo, teamName } = data;
  
    // Find the team by ID
    const team = await Team.findById(TeamId);
  
    if (!team) {
      throw CustomErrorHandler.notFound("Team Not Found");
    }
  
    if (teamLogo) {
      const imagePath = await ImageUploader.Upload(
        teamLogo,
        "edit-team",
        team.teamLogo
      );
      team.teamLogo = imagePath;
    }
  
    team.teamName = teamName;
  
    // Save the updated team data
    let teamData = await team.save();
    return teamData;
  },
  
  // async addPlayer(data, TeamId) {
  //   const { name, phoneNumber,role } = data;
  
  //   const team = await Team.findById(TeamId);
  
  //   if (!team) {
  //     throw CustomErrorHandler.notFound("Team Not Found");
  //   }
  
  //   if (team.players.length >= 15) {
  //     throw CustomErrorHandler.badRequest(
  //       "Team is already at maximum capacity (15 players)"
  //     );
  //   }
  
  //   // Check if the player already exists in the team
  //   const existingPlayer = await Player.findOne({
  //     team: TeamId,
  //     phoneNumber: phoneNumber,
  //   });
  
  //   if (existingPlayer) {
  //     throw CustomErrorHandler.badRequest(
  //       "Player with the same phone number already exists in the team."
  //     );
  //   }
  
  //   // Check if the user exists or create a new one
  //   const existingUser = await User.findOne({ phoneNumber: phoneNumber });
  //   let userId;
  //   let fcmToken;
  //   if (existingUser) {
  //     userId = existingUser._id;
  //     fcmToken = existingUser.fcmToken;
  //   } else {
  //     const newUser = new User({
  //       fullName: name,
  //       phoneNumber: phoneNumber,
  //       registrationDate: new Date(),
  //     });
  
  //     const newUserData = await newUser.save();
  //     userId = newUserData._id;
  //     fcmToken = newUserData.fcmToken;
  //   }
  
  //   // Create a new player
  //   const player = new Player({
  //     name: name,
  //     phoneNumber: phoneNumber,
  //     team: TeamId,
  //     userId: userId,
  //     role: role,
  //   });
  
  //   let playerData = await player.save();
  
  //   // Add player to the team
  //   team.players.push(playerData._id);
  
  //   // Set the first player added as the captain
  //   if (team.players.length === 1) {
  //     team.captain = playerData._id; // Set the first player as the default captain
  //   }
  
  //   let teamdata = await team.save();
  
  //   return { teamdata, fcmToken };
  // },
  
  async addPlayer(data, TeamId, currentUser) {
    const { name, phoneNumber, role } = data;
  
    const team = await Team.findById(TeamId);
  
    if (!team) {
      throw CustomErrorHandler.notFound("Team Not Found");
    }
  
    if (team.players.length >= 15) {
      throw CustomErrorHandler.badRequest("Team is already at maximum capacity (15 players)");
    }
  
    // Check if the player already exists in the team
    const existingPlayer = await Player.findOne({
      team: TeamId,
      phoneNumber: phoneNumber,
    });
  
    if (existingPlayer) {
      throw CustomErrorHandler.badRequest(
        "Player with the same phone number already exists in the team."
      );
    }
  
    // Check if the user exists or create a new one
    const existingUser = await User.findOne({ phoneNumber: phoneNumber });
    let userId;
    let fcmToken;
  
    if (existingUser) {
      userId = existingUser._id;
      fcmToken = existingUser.fcmToken;
    } else {
      const newUser = new User({
        fullName: name,
        phoneNumber: phoneNumber,
        registrationDate: new Date(),
      });
  
      const newUserData = await newUser.save();
      userId = newUserData._id;
      fcmToken = newUserData.fcmToken;
    }
  
    // Create a new player
    const player = new Player({
      name: name,
      phoneNumber: phoneNumber,
      team: TeamId,
      userId: userId,
      role: role,
    });
  
    let playerData = await player.save();
  
    // Assign the first player as captain
    if (team.players.length === 0) {
      team.captain = playerData._id;
  
      // Save captain role in the database
      const captain = new Player({
        name: currentUser.name,
        phoneNumber: currentUser.phoneNumber,
        team: TeamId,
        userId: currentUser._id,
        role: "Captain",
      });
      await captain.save();
    }
  
    // Add player to the team
    team.players.push(playerData._id);
  
    let teamdata = await team.save();
  
    return { teamdata, fcmToken };
  },
  
  async deletePlayer(teamId, playerId) {
    const team = await Team.findById(teamId);
  
    if (!team) {
      throw CustomErrorHandler.notFound("Team Not Found");
    }
  
    const playerIndex = team.players.findIndex((player) =>
      player._id.equals(playerId)
    );
  
    if (playerIndex === -1) {
      throw CustomErrorHandler.notFound("Player Not Found in the team");
    }
  
    // Remove the player from the team
    team.players.splice(playerIndex, 1);
  
    // // If the player being deleted was the captain, reassign the first player as the new captain
    // if (team.captain.toString() === playerId && team.players.length > 0) {
    //   team.captain = team.players[0]._id; // Assign the first player as the new captain
    // }
    if (team.captain && team.captain.toString() === playerId && team.players.length > 0) {
      team.captain = team.players[0]._id; // Assign the first player as the new captain
    }
    
    // Save the updated team data
    await team.save();
  
    // Delete the player from the Player collection
    await Player.deleteOne({ _id: playerId });
  
    return team;
  },
  async changeCaptain(userId, teamId, newCaptainId, newRole, previousCaptainId, previousCaptainRole) {
    // Fetch team data and populate players
    const team = await Team.findById(teamId).populate('players');
    console.log("Fetched Team: ", team);  // Debugging log to verify team and players

    // Check if team exists
    if (!team) {
        throw CustomErrorHandler.notFound("Team Not Found");
    }

    // Ensure `players` array exists and is populated
    if (!team.players || team.players.length === 0) {
        throw CustomErrorHandler.notFound("No players found in the team");
    }

    // Find the current captain by comparing userId or _id with team.captain
    const currentCaptain = team.players.find(player => player._id.toString() === previousCaptainId);
    console.log("Current Captain: ", currentCaptain);  // Debugging log to verify current captain

    // If there is no current captain, throw an error
    if (!currentCaptain) {
        throw CustomErrorHandler.notFound("Current captain not found in the team");
    }

    // If the new captain is the current captain, skip the update
    if (currentCaptain._id.toString() === newCaptainId) {
        throw CustomErrorHandler.badRequest("This player is already the captain");
    }

    // Find the new captain
    const newCaptain = team.players.find(player => player._id.toString() === newCaptainId);
    if (!newCaptain) {
        throw CustomErrorHandler.notFound("New captain not found in this team");
    }

    // If there is a current captain, update their role to the specified new role (or default)
    if (currentCaptain) {
        // Validate and update the previous captain's role
        if (previousCaptainRole && !["Batsman", "Bowler", "All Rounder", "Wicket Keeper"].includes(previousCaptainRole)) {
            throw CustomErrorHandler.badRequest("Previous captain's role must be one of 'Batsman', 'Bowler', 'All Rounder', or 'Wicket Keeper'");
        }

        // Update the role of the previous captain to a non-captain role
        currentCaptain.role = previousCaptainRole || "Batsman"; // Default to "Batsman" if not provided
        await currentCaptain.save();  // Save updated role for the previous captain
    }

    // Update team with new captain
    team.captain = newCaptain._id;

    // Optional: Update role of the new captain if a new role is provided
    newCaptain.role = newRole;
    await newCaptain.save();  // Save updated role for the new captain

    // Save the updated team
    await team.save();

    // Return data with both previous and new captain details
    return {
        teamId: team._id,
        newCaptain: {
            id: newCaptain._id,
            name: newCaptain.name,
            role: newCaptain.role,
        },
        previousCaptain: {
            id: currentCaptain._id,
            name: currentCaptain.name,
            role: currentCaptain.role,
        },
    };
},

//   async changeCaptain(userId, teamId, newCaptainId, newRole) {
//     // Fetch team data and populate players
//     const team = await Team.findById(teamId).populate("players");

//     if (!team) {
//         throw CustomErrorHandler.notFound("Team Not Found");
//     }

//     // Debugging Logs
//     console.log("Team Data:", team);
//     console.log("Requester UserId:", userId);

//     // Ensure `players` array exists and is populated
//     if (!team.players || team.players.length === 0) {
//         throw CustomErrorHandler.notFound("No players found in the team");
//     }

//     // Check if the requester is part of the team
//     const requester = team.players.find(
//         (player) => player?.userId?.toString() === userId.toString()
//     );
//     if (!requester) {
//         throw CustomErrorHandler.unAuthorized("You are not a member of this team");
//     }

//     // Validate that the new captain is part of the team
//     const newCaptain = team.players.find(
//         (player) => player?._id?.toString() === newCaptainId.toString()
//     );
//     if (!newCaptain) {
//         throw CustomErrorHandler.notFound("New Captain not found in the team");
//     }

//     // Ensure the current captain or any player can change the captain
//     if (team.captain && requester._id.toString() !== team.captain.toString()) {
//         if (!team.players.some((player) => player?._id?.toString() === userId.toString())) {
//             throw CustomErrorHandler.unAuthorized("Only team members can change the captain");
//         }
//     }

//     // Update the previous captain's role if a captain already exists
//     if (team.captain) {
//         const previousCaptain = await Player.findById(team.captain);
//         if (previousCaptain) {
//             previousCaptain.role = "Batsman"; // Default to a role, e.g., Batsman
//             await previousCaptain.save();
//         }
//     }

//     // Update the captain field and assign the new role to the new captain
//     team.captain = newCaptain._id;
//     newCaptain.role = newRole || "Captain";
//     await newCaptain.save();

//     // Save the updated team data
//     const updatedTeam = await team.save();
//     return updatedTeam;
// },



  // async editTeam(data, TeamId) {
  //   const { teamLogo, teamName } = data;
  //   const userInfo = global.user;

  //   // Find the tournament by ID
  //   const team = await Team.findById(TeamId);

  //   if (!team) {
  //     // Handle the case where the tournament is not found
  //     throw CustomErrorHandler.notFound("team Not Found");
  //   }

  //   if (teamLogo) {
  //     const imagePath = await ImageUploader.Upload(
  //       teamLogo,
  //       "create-team",
  //       team.teamLogo
  //     );
  //     team.teamLogo = imagePath;
  //   }
  //   team.teamName = teamName;

  //   // Update the tournament's isDeleted is true;
  //   // if (teamLogo) {
  //   // }

  //   // Save the updated user document
  //   let teamData = await team.save();
  //   return teamData;
  // },

  // async addPlayer(data, TeamId) {
  //   const { name, phoneNumber, role } = data;
  //   const userInfo = global.user;

  //   const team = await Team.findById(TeamId);

  //   if (!team) {
  //     // Handle the case where the tournament is not found
  //     throw CustomErrorHandler.notFound("team Not Found");
  //   }

  //   if (team.players.length >= 15) {
  //     throw CustomErrorHandler.badRequest(
  //       "Team is already at maximum capacity (15 players)"
  //     );
  //   }

  //   const existingPlayer = await Player.findOne({
  //     team: TeamId,
  //     phoneNumber: phoneNumber,
  //   });

  //   if (existingPlayer) {
  //     throw CustomErrorHandler.badRequest(
  //       "Player with the same phone number already exists in the team."
  //     );
  //   }
  //   // did change in user User.exist
  //   const existingUser = await User.findOne({ phoneNumber: phoneNumber });
  //   let userId;
  //   let fcmToken;
  //   if (existingUser) {
  //     userId = existingUser._id;
  //     fcmToken = existingUser.fcmToken; // Added notification
  //   } else {
  //     const newUser = new User({
  //       fullName: name,
  //       phoneNumber: phoneNumber,
  //       registrationDate: new Date(),
  //     });

  //     const newUserData = await newUser.save();
  //     userId = newUserData._id;
  //     fcmToken = newUserData.fcmToken;
  //   }

  //   const player = new Player({
  //     name: name,
  //     phoneNumber: phoneNumber,
  //     role: role,
  //     team: TeamId,
  //     userId: userId,
  //   });

  //   let playerData = await player.save();

  //   team.players.push(playerData._id);

  //   let teamdata = await team.save();
  //   return { teamdata, fcmToken };
  // },

  // async deletePlayer(teamId, playerId) {
  //   // const userInfo = global.user;

  //   // Find the tournament by ID
  //   const team = await Team.findById(teamId);

  //   if (!team) {
  //     // Handle the case where the tournament is not found
  //     throw CustomErrorHandler.notFound("team Not Found");
  //   }
  //   // Delete the player from the team players collection
  //   await Player.deleteOne({ _id: playerId });

  //   // Remove the player from the team's 'players' array
  //   team.players = team.players.filter((p) => !p._id.equals(playerId));

  //   // Save the updated team after removing the player
  //   await team.save();

  //   return team;
  // },

  async getAllTeamNearByMe() {
    //Find the Banner
    let teamData = await Team.find();

    if (!teamData) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("Team Not Found");
    }
    return teamData;
  },

  async addLookingFor(data) {
    const { placeName, longitude, latitude, role } = data;
    const userInfo = global.user;

    const looking = new Lookingfor({
      userId: userInfo.userId,
      role: role,
      location: {
        type: "Point",
        coordinates: [parseFloat(longitude), parseFloat(latitude)],
        selectLocation: placeName,
      },
    });

    const lookingData = await looking.save();

    return lookingData;
  },

  async deleteLookingFor(lookingId) {
    // Delete the player from the team players collection
    await Lookingfor.deleteOne({ _id: lookingId });
  },

  async getAllLooking(data) {
    const { latitude, longitude } = data;
    const maxDistanceInKm = 30;
    // Find the Banner

    const looking = await Lookingfor.aggregate([
      {
        $geoNear: {
          near: {
            type: "Point",
            coordinates: [parseFloat(longitude), parseFloat(latitude)],
          },

          distanceField: "distance",
          spherical: true,
          distanceCalc: "dist.calculated",
          key: "location", // Specify the index key
        },
      },
      {
        $addFields: {
          distanceInKm: {
            $divide: ["$distance", 1000],
          },
        },
      },
      {
        $lookup: {
          from: "users",
          localField: "userId", // Update to the correct field in Lookingfor schema
          foreignField: "_id",
          as: "user",
        },
      },
      {
        $match: {
          distanceInKm: { $lt: 6 }, // Adjust as needed 3000 meaks 3km
        },
      },
      {
        $unwind: "$user",
      },
      {
        $project: {
          _id: 1,
          role: 1,
          latitude: 1,
          longitude: 1,
          location: "$location.selectLocation",
          createdAt: 1,
          email: "$user.email",
          phoneNumber: "$user.phoneNumber",
          fullName: "$user.fullName",
          distanceInKm: 1,
        },
      },
      {
        $sort: {
          createdAt: -1, // Sort by createdAt field in descending order (newest first)
        },
      },
      {
        $limit: 50, // Limit the number of results to 50
      },
    ]);

    if (!looking) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("Team Not Found");
    }
    return { data: looking };
  },

  async getLookingByID() {
    const userInfo = global.user;

    const looking = await Lookingfor.aggregate([
      {
        $match: {
          userId: new Types.ObjectId(userInfo.userId),
        },
      },
      {
        $lookup: {
          from: "users", // Name of the collection you're joining with
          localField: "userId", // Field in the current collection that references the users collection
          foreignField: "_id", // Field in the 'users' collection to match with
          as: "User", // Output array field name
        },
      },
      {
        $project: {
          _id: 1,
          role: 1,
          location: "$location.selectLocation",
          createdAt: 1,
          userEmail: { $arrayElemAt: ["$User.email", 0] }, // Extract email field from User array
          fullName: { $arrayElemAt: ["$User.fullName", 0] }, // Extract fullName field from User array
          phoneNumber: { $arrayElemAt: ["$User.phoneNumber", 0] }, // Extract phoneNumber field from User array
        },
      },
    ]);

    if (!looking) {
      // Handle the case where the user is not found
      throw CustomErrorHandler.notFound("looking Not Found");
    }
    return looking;
  },

  async getAllNearByTeam(data) {
    const { latitude, longitude } = data;
    const userInfo = global.user;

    const NearByTeams = await User.aggregate([
      {
        $geoNear: {
          near: {
            type: "Point",
            coordinates: [parseFloat(longitude), parseFloat(latitude)],
          },

          distanceField: "distance",
          spherical: true,
          // distanceCalc: "dist.calculated",

          query: {
            isDeleted: false,
            isNewUser: false,
          },
          key: "location", // Specify the index key
        },
      },
      {
        $addFields: {
          distanceInKm: {
            $divide: ["$distance", 1000],
          },
        },
      },
      {
        $match: {
          distanceInKm: { $lt: 30 }, // Adjust as needed 3000 meaks 3km
        },
      },
      {
        $match: {
          _id: { $ne: ObjectId(userInfo.userId) }, // Filter out the user with the specified userId
        },
      },
      {
        $lookup: {
          from: "teams", // Replace with the actual name of your teams collection
          localField: "_id",
          foreignField: "userId",
          as: "teams",
        },
      },
      {
        $project: {
          fullName: 1,
          email: 1,
          distanceInKm: 1,
          "teams.teamName": 1,
          "teams.teamLogo": 1,
          "teams._id": 1,
          // Add other fields you want to include in the result
        },
      },
    ]);

    return NearByTeams;
  },

  async getTeamCount() {
    //Find the Banner
    const totalTeams = await Team.countDocuments();
    return totalTeams;
  },

  

  // async editPlayer(data, TeamId,playerId) {
  //   const { name, phoneNumber, role } = data;
  //   const userInfo = global.user;

  //   const team = await Team.findById(TeamId);

  //   if (!team) {
  //     // Handle the case where the tournament is not found
  //     throw CustomErrorHandler.notFound("team Not Found");
  //   }

  //   const player = await Player.findById(playerId);

  //   if (!player) {
  //     // Handle the case where the tournament is not found
  //     throw CustomErrorHandler.notFound("player Not Found");
  //   }

  //    // Update the tournament's isDeleted is true;
  //    player.isDeleted = true;
  //    player.isDeleted = true;
  //    player.isDeleted = true;
  //    // Save the updated user document
  //    let tournamentdata = await player.save();

  // // Find the player to be edited within the 'players' array
  // const playerIndex = team.Player.findIndex(
  //   (p) => p._id.toString() === playerId
  // );

  // if (playerIndex === -1) {
  //   throw CustomErrorHandler.badRequest(
  //     "Player not found in the specified team."
  //   );
  // }

  // // Update the player's information within the 'players' array
  // team.players[playerIndex].name = updatedPlayerInfo.name;
  // team.players[playerIndex].phoneNumber = updatedPlayerInfo.phoneNumber;
  // team.players[playerIndex].role = updatedPlayerInfo.role;

  // // Save the updated team
  // await team.save();

  //   const existingUser = await User.exists({ phoneNumber: phoneNumber });
  //   let userId;
  //   if (existingUser) {
  //     userId=existingUser._id
  //   }

  //   const player = new Player({
  //     name: name,
  //     phoneNumber: phoneNumber,
  //     role: role,
  //     team: TeamId,
  //     userId: userId
  //   });

  //  let playerData = await player.save();

  //   team.players.push(playerData._id);

  //   let teamdata = await team.save();
  //   return teamdata;
  // },


  
  
//DG 
async updatePointsTable(matchResult) {
  const {
      winningTeamId,
      losingTeamId,
      isTie,
      noResult,
      bonusPoint,
      teamStats,
  } = matchResult;

  // Fetch winning and losing teams
  const winningTeam = await RegisteredTeam.findOne({ team: winningTeamId });
  const losingTeam = losingTeamId ? await RegisteredTeam.findOne({ team: losingTeamId }) : null;

  if (!winningTeam) throw new Error("Winning team not found");

  // const calculateNetRunRate = (team, stats, isLosingTeam = false) => {
  //     const { runsScored, oversFaced, runsConceded, oversBowled } = stats;
  //     const runRateFor = runsScored / oversFaced;
  //     const runRateAgainst = runsConceded / oversBowled;

  //     return isLosingTeam
  //         ? team.netRunRate - (runRateAgainst - runRateFor)
  //         : team.netRunRate + (runRateFor - runRateAgainst);
  // };

  const calculateNetRunRate = (team, stats, isLosingTeam = false) => {
    const { runsScored, oversFaced, runsConceded, oversBowled } = stats;
    const runRateFor = runsScored / oversFaced;
    const runRateAgainst = runsConceded / oversBowled;

    const netRunRateChange = isLosingTeam
        ? runRateAgainst - runRateFor
        : runRateFor - runRateAgainst;

    // Update net run rate and round to 2 decimal places
    return parseFloat((team.netRunRate + netRunRateChange).toFixed(2));
};

  // Update stats based on match result
  winningTeam.matchesPlayed += 1;
  if (isTie) {
      winningTeam.ties += 1;
      winningTeam.points += 1;

      if (losingTeam) {
          losingTeam.matchesPlayed += 1;
          losingTeam.ties += 1;
          losingTeam.points += 1;
      }
  } else if (noResult) {
      winningTeam.noResult += 1;
      winningTeam.points += 1;

      if (losingTeam) {
          losingTeam.matchesPlayed += 1;
          losingTeam.noResult += 1;
          losingTeam.points += 1;
      }
  } else {
      winningTeam.wins += 1;
      winningTeam.points += 2 + (bonusPoint ? 1 : 0);

      if (losingTeam) {
          losingTeam.matchesPlayed += 1;
          losingTeam.losses += 1;
      }

      // Update NRR if stats are provided
      if (teamStats) {
          winningTeam.netRunRate = calculateNetRunRate(winningTeam, teamStats);
          if (losingTeam) {
              losingTeam.netRunRate = calculateNetRunRate(losingTeam, teamStats, true);
          }
      }
  }

  // Save changes
  await winningTeam.save();
  if (losingTeam) await losingTeam.save();
},

async getPointsTable(tournamentId) {
    try {
        const registeredTeams = await RegisteredTeam.find(
            { tournament: tournamentId, status: "Accepted" },
            {
                team: 1,
                matchesPlayed: 1,
                wins: 1,
                losses: 1,
                ties: 1,
                noResult: 1,
                points: 1,
                netRunRate: 1,
            }
        ).populate("team");

        if (!registeredTeams || registeredTeams.length === 0) {
            throw new Error("No registered teams found for the given tournament.");
        }

        const updatedTeams = registeredTeams.map((regTeam) => {
            const team = regTeam.team;
            if (!team) return null;

            return {
                teamId: team._id,
                teamName: team.teamName,
                teamLogo: team.teamLogo,
                matchesPlayed: regTeam.matchesPlayed,
                wins: regTeam.wins,
                losses: regTeam.losses,
                ties: regTeam.ties,
                noResult: regTeam.noResult,
                points: regTeam.wins * 2 + regTeam.ties,
                netRunRate: regTeam.netRunRate,
            };
        }).filter(Boolean);

        updatedTeams.sort((a, b) => {
            if (a.points === b.points) {
                if (a.wins === b.wins) {
                    return b.netRunRate - a.netRunRate;
                }
                return b.wins - a.wins;
            }
            return b.points - a.points;
        });

        return updatedTeams.map((team, index) => ({
            rank: index + 1,
            ...team,
        }));
    } catch (error) {
        console.error("Error fetching points table:", error.message);
        throw new Error("Failed to fetch points table.");
    }
},






};

export default teamServices;
