export { default as otherServices } from "./otherServices.js";

export { default as teamServices } from "./teamServices.js";

export { default as tournamentServices } from "./tournamentServices.js";

export { default as userServices } from "./userServices.js";

export {default as authServices } from "./authServices.js";

export {default as matchServices} from "./matchServices.js"

export {default as bannerService } from "./bannerPromoService.js"

//admin

export {default as adminService} from "./adminService.js";