import mongoose from "mongoose";
import autopopulate from "mongoose-autopopulate";
const teamSchema = new mongoose.Schema({
  _id: {
     type: mongoose.Schema.Types.ObjectId, auto: true
   },
 teamLogo: {
    type: String,
  },
  teamName: {
    type: String,
  },
  players: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Player",
      autopopulate: true,
    },
  ],
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
 
  teamMatchsData:{
        tennis: {
         
        },
        leather: {
         
        },
  }, 
  numberOfWins:{
    type: Number,
  },
  //below fields added by DG for pointsTable api
  // matchesPlayed: {
  //   type: Number,
  //   default: 0,
  // },
  // wins: {
  //   type: Number,
  //   default: 0,
  // },
  // losses: {
  //   type: Number,
  //   default: 0,
  // },
  // ties: {
  //   type: Number,
  //   default: 0,
  // },
  // noResult: {
  //   type: Number,
  //   default: 0,
  // },
  // points: {
  //   type: Number,
  //   default: 0,
  // },
  // netRunRate: {
  //   type: Number,
  //   default: 0, // NRR
  // },
},


);
teamSchema.plugin(autopopulate);
teamSchema.set('timestamps', true);

export default mongoose.model("Team", teamSchema);


