import { Banner } from '../models/index.js';
import ImageUploader from '../helpers/ImageUploader.js';
import Joi from 'joi';

const bannerService = {
    async createBanner(data) {
        const schema = Joi.object({
            image: Joi.string().required().pattern(/^data:image\/(png|jpeg|jpg);base64,/),
            promotionLocation: Joi.array().items(Joi.string().valid('Home Screen', 'Score Summary', 'Search Screen')).required(),
            startDate: Joi.date().required(),
            endDate: Joi.date().min(Joi.ref('startDate')).required(),
            locationHistory: Joi.object({
                point: Joi.object({
                    type: Joi.string().valid('Point').default('Point'),
                    coordinates: Joi.array().items(Joi.number()).length(2).required()
                }).required()
            }).required(),
            promotionFor: Joi.string().valid('Tournament', 'Shop').required(),
            userId: Joi.string().required(),
            payments: Joi.array().items(
                Joi.object({
                    paymentid: Joi.string().required(),
                    amount: Joi.number().positive().required()
                })
            )
        });

        const { error } = schema.validate(data);
        if (error) {
            throw new Error(`Validation error: ${error.details.map(e => e.message).join(', ')}`);
        }

        const { image, promotionLocation, startDate, endDate, locationHistory, promotionFor, userId, payments } = data;

        const folderName = 'bannerPromotion';
        const fileName = `${Date.now().toString()}.jpg`;
        const s3Key = await ImageUploader.Upload(image, folderName, fileName);

        const newBanner = new Banner({
            image: s3Key,
            promotionLocation,
            startDate,
            endDate,
            locationHistory,
            promotionFor,
            userId,
            payments
        });

        try {
            await newBanner.save();
            return { message: 'Banner Created Successfully', banner: newBanner };
        } catch (error) {
            throw new Error(`Error saving banner: ${error.message}`);
        }
    }
};

export default bannerService;

