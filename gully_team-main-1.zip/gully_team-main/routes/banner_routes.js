import express from "express";
const router = express.Router();
import { bannerController } from "../controllers/index.js";
import validateUser from '../middlewares/validateUser.js';

router.post('/createbanner',validateUser, bannerController.createBanner);
// router.get('/getbanner/:id',validateUser, bannerController.getBanner);
router.put('/updatebanner/:id', validateUser,bannerController.updateBanner);
router.delete('/deletebanner/:id',validateUser, bannerController.deleteBanner);

// POST route to get tournaments for the logged-in user within the specified date range
router.post('/gettournaments', bannerController.getTournaments);

// GET route to get shops for the logged-in user
router.get('/getshops', bannerController.getShops);

export default router;

